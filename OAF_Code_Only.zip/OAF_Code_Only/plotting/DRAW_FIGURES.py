"""Reproduce Figures 2--5 from archived results. No fitting or model selection.
Run: python DRAW_FIGURES.py
Change STYLE, COLORS and figure sizes below to customize the artwork.
"""
from pathlib import Path
import json
import hashlib
from io import BytesIO
from PIL import Image
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator, FormatStrFormatter
from matplotlib.colors import TwoSlopeNorm, LinearSegmentedColormap
from sklearn.metrics import roc_curve, precision_recall_curve, roc_auc_score, average_precision_score

ROOT = Path(__file__).resolve().parent
DATA, OUT = ROOT / 'data', ROOT / 'figures'
OUT.mkdir(exist_ok=True)
COLORS = {'RF':'#3F73AD','OAF':'#287A3D','LR':'#A2A9B0','LightGBM':'#A78A50',
          'GRUD':'#867A9D','Raindrop':'#B47770','Combined':'#819DB9',
          'Global':'#A78A50','Unshrunk':'#867A9D','Fixed':'#B47770',
          'Site A':'#4B5563','Site B':'#4B5563'}
STYLE = {'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8,
         'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,
         'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.75,
         'axes.edgecolor':'#BEC8CF','grid.color':'#E8EDF0','grid.linewidth':.45,
         'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'}
plt.rcParams.update(STYLE)

def read(name): return pd.read_csv(DATA / name)
def compact_axes(fig):
    # Identical physical widths/heights and common upper/lower edges.
    fig._compact_main = True
    h = 7.2 * .20 / 2.55
    return [fig.add_axes([x,.205,.20,h]) for x in [.10,.415,.765]]

def panel(ax, letter, title):
    if getattr(ax.figure, '_compact_main', False):
        pos = ax.get_position()
        ax.figure.text(pos.x0, .815, f'({letter})', fontsize=8.2,
                       fontweight='bold', ha='left', va='baseline')
        ax.figure.text(pos.x0+.035, .815, title, fontsize=8.2,
                       fontweight='normal', ha='left', va='baseline')
    else:
        ax.set_title(f'({letter})  {title}',loc='left',fontweight='normal',pad=9)
def grid(ax,axis='both'):
    ax.grid(axis=axis,alpha=.85);ax.set_axisbelow(True);ax.tick_params(length=3,color='#8E9BA5')
def save(fig,name):
    for ext in ['png','pdf','svg']:
        buffer=BytesIO()
        fig.savefig(buffer,format=ext,dpi=600,
                    bbox_inches=None if getattr(fig,'_compact_main',False) else 'tight',
                    pad_inches=.06)
        payload=buffer.getvalue()
        if ext=='png':
            with Image.open(BytesIO(payload)) as im: im.load()
        temporary=OUT / f'{name}.{ext}.tmp'
        temporary.write_bytes(payload)
        temporary.replace(OUT / f'{name}.{ext}')
    if getattr(fig,'_compact_main',False):
        fig.canvas.draw()
        positions=[list(ax.get_position().bounds) for ax in fig.axes[:3]]
        renderer=fig.canvas.get_renderer()
        canvas_box=fig.bbox
        hidden_tick_text=set()
        for ax in fig.axes:
            for axis,limits in [(ax.xaxis,ax.get_xlim()),(ax.yaxis,ax.get_ylim())]:
                low,high=sorted(limits)
                for tick in axis.get_major_ticks():
                    if not low-1e-10<=tick.get_loc()<=high+1e-10:
                        hidden_tick_text.update([id(tick.label1),id(tick.label2)])
        for txt in fig.findobj(matplotlib.text.Text):
            if id(txt) in hidden_tick_text: continue
            if not txt.get_visible() or not txt.get_text().strip(): continue
            box=txt.get_window_extent(renderer)
            if box.width>0 and box.height>0:
                assert box.x0>=canvas_box.x0-1 and box.x1<=canvas_box.x1+1 and box.y0>=canvas_box.y0-1 and box.y1<=canvas_box.y1+1, (name,txt.get_text(),list(box.bounds))
        assert max(p[1] for p in positions)-min(p[1] for p in positions)<1e-9
        assert max(p[3] for p in positions)-min(p[3] for p in positions)<1e-9
        (OUT/f'{name}_layout.json').write_text(json.dumps({'inches':list(fig.get_size_inches()),'panel_bounds':positions,'panel_label_baseline':.815,'legends':'top only'},indent=2))
    plt.close(fig)
def interval(ax,x,y,lo,hi,color,marker='o',size=5):
    ax.errorbar(x,y,xerr=[[x-lo],[hi-x]],fmt=marker,color=color,
                ms=size,lw=1.15,capsize=2.5,capthick=.9,zorder=3,markerfacecolor='white' if marker=='s' and color==COLORS['Site B'] else color)
def site_handles():
    return [Line2D([],[],marker=mk,ls='',color=COLORS[s],label=s,
                   markersize=4.5,markerfacecolor='white' if s=='Site B' else COLORS[s]) for s,mk in [('Site A','o'),('Site B','s')]]

def figure2():
    absolute,paired=read('common_absolute.csv'),read('common_paired.csv')
    gaps,site=read('common_cross_campus_gaps.csv'),read('query_time_site_diagnostic.csv')
    fig=plt.figure(figsize=(7.2,2.55))
    gs=compact_axes(fig)
    diag_handles=[Line2D([],[],marker='o',ls='',color=COLORS['LR'],label='LR'),Line2D([],[],marker='D',ls='',color=COLORS['RF'],label='RF')]
    fig.legend(handles=diag_handles+site_handles(),loc='upper center',bbox_to_anchor=(.52,.985),
               ncol=4,frameon=False,fontsize=7.5,columnspacing=1.8,handletextpad=.5)
    ax=gs[0]
    for model,offset,color,mk in [('LR',-.20,COLORS['LR'],'o'),('RF',.20,COLORS['RF'],'D')]:
        for j,f in enumerate(['repeat_only','full_query_observation']):
            r=site[(site.learner==model)&(site.feature_set==f)&(site.stratum=='all')].iloc[0]
            ax.errorbar(j+offset,r.AUROC,yerr=[[r.AUROC-r.ci_low],[r.ci_high-r.AUROC]],fmt=mk,color=color,capsize=3,ms=5,label=model if j==0 else None)
            ax.text(j+offset,r.ci_high+(.028 if model=='LR' else .008),f'{r.AUROC:.3f}',ha='center',va='bottom',fontsize=7,color=color)
    ax.axhline(.5,color='#939FA8',ls=':',lw=1)
    ax.set(xticks=[0,1],xticklabels=['R only','Full obs.'],xlim=(-.45,1.45),ylim=(.48,.87),ylabel='Campus AUROC',xlabel='Observation features')
    grid(ax,'y');panel(ax,'a','Campus separability')
    ax=gs[1]
    contrasts=['B-A','C-A','D-C','D-A','E-C'];records=[];values=np.empty((5,3));flags=np.zeros((5,3),dtype=bool)
    for j,k in enumerate(contrasts):
        for c,site in enumerate(['Site A','Site B']):
            r=paired[(paired.cohort==site)&(paired.contrast==k)&(paired.metric=='AUPRC')].iloc[0]
            values[j,c]=r.estimate;flags[j,c]=(r.ci_low>0 or r.ci_high<0)
            records.append(dict(contrast=k,column=site,estimate=r.estimate,ci_low=r.ci_low,ci_high=r.ci_high))
        r=gaps[(gaps.contrast==k)&(gaps.metric=='AUPRC')].iloc[0]
        values[j,2]=r.gap;flags[j,2]=(r.ci_low>0 or r.ci_high<0)
        records.append(dict(contrast=k,column='B minus A gap',estimate=r.gap,ci_low=r.ci_low,ci_high=r.ci_high))
    cmap=LinearSegmentedColormap.from_list('effects',['#D69C70','#FCFCFA','#78A1C6'])
    im=ax.imshow(values,cmap=cmap,norm=TwoSlopeNorm(vmin=-.075,vcenter=0,vmax=.075),aspect='auto')
    for j in range(5):
        for c in range(3):ax.text(c,j,f'{values[j,c]:+.3f}'+('*' if flags[j,c] else ''),ha='center',va='center',fontsize=7.1,color='#263238')
    ax.set(xticks=range(3),xticklabels=['Site A','Site B','Gap'],yticks=range(5),yticklabels=['B − A','C − A','D − C','D − A','E − C'])
    ax.tick_params(length=0);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_visible(False)
    cb=fig.colorbar(im,cax=fig.add_axes([.415,.110,.20,.016]),orientation='horizontal',ticks=[-.06,0,.06])
    cb.ax.tick_params(labelsize=7,length=2,pad=2);cb.set_label('AUPRC increment / gap',fontsize=6.7,labelpad=1);cb.outline.set_visible(False)
    panel(ax,'b','RF source effects')
    pd.DataFrame(records).to_csv(OUT/'figure2_effect_matrix.csv',index=False)
    ax=gs[2]
    contrasts=['OAF_shrink-A','OAF_shrink-D','OAF_shrink-Fixed_half','OAF_shrink-Global_weight','OAF_shrink-OAF_same6_no_shrink']
    for s,offset,mk in [('Site A',-.14,'o'),('Site B',.14,'s')]:
        for j,k in enumerate(contrasts):
            r=paired[(paired.cohort==s)&(paired.contrast==k)&(paired.metric=='AUPRC')].iloc[0]
            interval(ax,r.estimate,j+offset,r.ci_low,r.ci_high,COLORS[s],mk,4.5)
    ax.axvline(0,color='#919CA5',lw=1)
    ax.set(yticks=range(5),yticklabels=['RF-current','RF-history','50:50 blend','Global blend','Unshrunk gate'],
           ylim=(4.6,-.6),xlim=(-.07,.16),xlabel='OAF − reference\nAUPRC difference')
    ax.set_xticks([-.05,0,.10]);grid(ax,'x');panel(ax,'c','OAF contrasts')
    save(fig,'Figure2')
    fig,ax=plt.subplots(figsize=(5.0,2.7));fig.subplots_adjust(left=.16,right=.97,bottom=.18,top=.84)
    for campus,off in [('Site A',-.17),('Site B',.17)]:
        values=[absolute[(absolute.cohort==campus)&(absolute.model==m)&(absolute.metric=='AUPRC')].estimate.iloc[0] for m in 'ABCDE']
        ax.bar(np.arange(5)+off,values,width=.30,color=COLORS[campus] if campus=='Site A' else 'white',edgecolor=COLORS[campus],hatch='' if campus=='Site A' else '///',linewidth=.7,zorder=3)
    ax.set(xticks=range(5),xticklabels=['A','B','C','D','E'],ylim=(0,.90),ylabel='Patient-equal AUPRC',xlabel='Matched condition')
    grid(ax,'y');panel(ax,'a','Matched RF conditions')
    ax.legend(handles=site_handles(),frameon=False,loc='upper right',fontsize=8)
    save(fig,'Supplementary_matched_performance')

def figure3():
    d=read('six_model_predictions.csv')
    models=['LR_current','RF_current','LightGBM_current','GRUD','Raindrop_portable','OAF_shrink']
    labels=['LR-current','RF-current','LightGBM-current','GRU-D','Raindrop-portable','OAF']
    short=['LR','RF','LightGBM','GRU-D','Raindrop','OAF']
    colors=[COLORS[k] for k in ['LR','RF','LightGBM','GRUD','Raindrop','OAF']];styles=['--','--','-.','--',':','-']
    fig=plt.figure(figsize=(7.2,2.55))
    gs=compact_axes(fig)
    aucax=gs[0];pra=[gs[1],gs[2]];metrics=[]
    rocfig,rocaxes=plt.subplots(1,2,figsize=(7.2,3.3));rocfig.subplots_adjust(left=.10,right=.98,bottom=.18,top=.75,wspace=.29)
    for row,(cohort,title) in enumerate([('xuhui_oof','Site A · OOF'),('fengxian','Site B')]):
        z=d[d.cohort==cohort];y=z.target.to_numpy();w=1/z.patient_id.map(z.patient_id.value_counts()).to_numpy()
        for j,(m,label,col,style) in enumerate(zip(models,labels,colors,styles)):
            probs=z[m].to_numpy();auc=roc_auc_score(y,probs,sample_weight=w);ap=average_precision_score(y,probs,sample_weight=w)
            metrics.append(dict(cohort=cohort,model=m,AUROC=auc,AUPRC=ap))
            aucax.scatter(auc,j+(-.13 if row==0 else .13),s=22,marker='o' if row==0 else 's',facecolors=COLORS['Site A'] if row==0 else 'white',edgecolors=COLORS['Site A'],linewidths=1,zorder=3)
            pr,re,_=precision_recall_curve(y,probs,sample_weight=w);lw=1.8 if m=='OAF_shrink' else 1.05
            pra[row].step(re,pr,where='post',color=col,lw=lw,ls=style,
                          marker='s' if m=='OAF_shrink' else ('o' if m=='RF_current' else None),
                          markevery=max(1,len(re)//9),ms=2.4)
            f,t,_=roc_curve(y,probs,sample_weight=w);rocaxes[row].plot(f,t,color=col,lw=lw,ls=style,
                              marker='s' if m=='OAF_shrink' else ('o' if m=='RF_current' else None),
                              markevery=max(1,len(f)//9),ms=2.4)
        pra[row].axhline(np.average(y,weights=w),ls=':',color='#B9C3CA',lw=.75)
        pra[row].set(xlim=(0,1),ylim=(0,1),xticks=[0,.5,1],yticks=[0,.5,1],xlabel='Recall',ylabel='Precision');grid(pra[row]);panel(pra[row],'bc'[row],'Site A · PR' if row==0 else 'Site B · PR')
        rocaxes[row].plot([0,1],[0,1],':',color='#B9C3CA',lw=.75);rocaxes[row].set(xlim=(0,1),ylim=(0,1),xlabel='False positive rate',ylabel='True positive rate');grid(rocaxes[row]);panel(rocaxes[row],'ab'[row],title)
    aucax.set(yticks=range(6),yticklabels=short,ylim=(5.6,-.6),xlim=(.62,.86),xticks=[.65,.75,.85],xlabel='AUROC');grid(aucax,'x');panel(aucax,'a','Discrimination')
    # Campus keys join the model legend above the panel row.
    handles=[Line2D([],[],color=c,ls=ls,lw=1.7 if m=='OAF_shrink' else 1.1,label=l) for m,l,c,ls in zip(models,labels,colors,styles)]
    fig.legend(handles=handles+site_handles(),loc='upper center',bbox_to_anchor=(.53,.995),ncol=4,frameon=False,fontsize=7.2,handlelength=2.0,columnspacing=1.4,handletextpad=.5)
    rocfig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.55,1),ncol=3,frameon=False,fontsize=8)
    pd.DataFrame(metrics).to_csv(OUT/'figure3_recomputed_metrics.csv',index=False)
    save(fig,'Figure3');save(rocfig,'Supplementary_ROC')

def figure4():
    absolute,stress,response=read('common_absolute.csv'),read('common_stress_summary.csv'),read('response_table5.csv')
    configs=[('A','RF-current','RF'),('D','RF-history','Combined'),('Global_weight','Global blend','Global'),('OAF_same6_no_shrink','Unshrunk gate','Unshrunk'),('OAF_shrink','OAF','OAF')]
    fig=plt.figure(figsize=(7.2,2.55))
    gs=compact_axes(fig)
    topaxes=[gs[0],gs[1]]
    handles=[Line2D([],[],color=COLORS[c],ls='--' if c=='Combined' else '-',lw=2 if m=='OAF_shrink' else 1.3,marker='s' if c=='OAF' else 'o',ms=4,label=l) for m,l,c in configs]
    fig.legend(handles=handles+[Line2D([],[],ls='',label='')]+site_handles(),loc='upper center',bbox_to_anchor=(.52,.995),ncol=4,frameon=False,fontsize=7.2,columnspacing=1.3,handlelength=2.0,handletextpad=.5)
    for ax,s,title,letter in zip(topaxes,['Site A','Site B'],['Site A','Site B'],['a','b']):
        for m,label,c in configs:
            base=absolute[(absolute.cohort==s)&(absolute.model==m)&(absolute.metric=='AUPRC')].estimate.iloc[0]
            z=stress[(stress.cohort==s)&(stress.model==m)].sort_values('dropout')
            ax.plot(np.r_[0,z.dropout],np.r_[0,z.AUPRC.to_numpy()-base],'--o' if c=='Combined' else ('-s' if c=='OAF' else '-o'),color=COLORS[c],ms=4,lw=2 if c=='OAF' else 1.25)
        base_rf=absolute[(absolute.cohort==s)&(absolute.model=='A')&(absolute.metric=='AUPRC')].estimate.iloc[0]
        base_oaf=absolute[(absolute.cohort==s)&(absolute.model=='OAF_shrink')&(absolute.metric=='AUPRC')].estimate.iloc[0]
        ax.text(.03,.97,f'Baseline AUPRC\nRF {base_rf:.3f} · OAF {base_oaf:.3f}',transform=ax.transAxes,va='top',fontsize=7,color='#49545B')
        ax.axhline(0,color='#9FAAB1',lw=.8,ls=':')
        ax.set(xticks=[0,.2,.4],xlim=(-.015,.415),ylim=(-.01,.035),xlabel='Older-history deletion',ylabel='AUPRC change')
        ax.yaxis.set_major_locator(MaxNLocator(5));grid(ax);panel(ax,letter,title)
    ax=gs[2]
    for s,off,mk in [('Site A',-.13,'o'),('Site B',.13,'s')]:
        for j,c in enumerate(['Global blend','Unshrunk gate']):
            r=response[(response.cohort==s)&(response.comparator==c)].iloc[0]
            interval(ax,1000*r.reduction,j+off,1000*r.ci_low,1000*r.ci_high,COLORS[s],mk)
    ax.axvline(0,color='#919CA5',lw=1)
    ax.set(yticks=range(2),yticklabels=['Global blend','Unshrunk gate'],ylim=(1.6,-.65),xlim=(-3,6),xlabel=r'Response gap ($\times 10^{-3}$)')
    ax.xaxis.set_major_locator(MaxNLocator(4));grid(ax,'x');panel(ax,'c','Deletion response')
    # Shared campus legend is in the top header.
    save(fig,'Figure4')
    fig,ax=plt.subplots(figsize=(5,2.8));fig.subplots_adjust(left=.27,right=.98,bottom=.21,top=.81)
    for site,off,hatch in [('Site A',-.18,''),('Site B',.18,'///')]:
        z=response[response.cohort==site]
        vals=[z[z.comparator=='Global blend'].comparator_response.iloc[0],z.oaf_response.iloc[0],z[z.comparator=='Unshrunk gate'].comparator_response.iloc[0]]
        for j,(v,c) in enumerate(zip(vals,['Global','OAF','Unshrunk'])):
            ax.barh(j+off,v*1000,height=.30,color=COLORS[c],edgecolor='white',linewidth=.5,hatch=hatch,zorder=3)
            ax.text(v*1000+.12,j+off,f'{v*1000:.2f}',va='center',fontsize=7,color=COLORS[c])
    ax.set(yticks=range(3),yticklabels=['Global blend','OAF','Unshrunk gate'],ylim=(2.5,-.55),xlim=(0,9.4),xlabel=r'Mean $|\Delta p|$ ($\times 10^{-3}$)')
    ax.text(.98,.99,'Solid: A  ·  Hatched: B',transform=ax.transAxes,ha='right',va='top',fontsize=7,color='#566774')
    ax.xaxis.set_major_locator(MaxNLocator(4));grid(ax,'x');panel(ax,'a','Prediction response · 40% deletion')
    save(fig,'Supplementary_response_magnitude')

def figure5():
    pred,effects=read('ensemble_predictions.csv'),read('paired_ensemble_bootstrap.csv')
    fig=plt.figure(figsize=(7.2,2.55))
    gs=compact_axes(fig)
    bins=[]
    for j,(s,label) in enumerate([('xuhui_oof','Site A'),('fengxian','Site B')]):
        z=pred[pred.cohort==s];y=z.target.to_numpy();w=1/z.patient_id.map(z.patient_id.value_counts()).to_numpy()
        ax=gs[j];ax.plot([0,1],[0,1],':',color='#ADB9C2',lw=.8)
        for m in ['RF_current','OAF']:
            color=COLORS['RF' if m=='RF_current' else 'OAF']
            for suffix,ls in [('', '--'),('_cal','-')]:
                probs=z[m+suffix].to_numpy();group=pd.qcut(probs,5,labels=False,duplicates='drop')
                xv,yv=[],[]
                for k in np.unique(group):
                    ix=group==k;x=np.average(probs[ix],weights=w[ix]);o=np.average(y[ix],weights=w[ix]);xv.append(x);yv.append(o)
                    bins.append(dict(cohort=s,model=m+suffix,bin=int(k),predicted=x,observed=o,landmark_n=int(ix.sum()),unique_patients=int(z.loc[ix,'patient_id'].nunique()),patient_weight=float(w[ix].sum())))
                ax.plot(xv,yv,ls,marker='o' if m=='RF_current' else 's',ms=3.5 if suffix else 3,lw=1.7 if suffix else .9,color=color,alpha=1 if suffix else .55)
        ax.set(xlim=(0,1),ylim=(0,1),xticks=[0,.5,1],yticks=[0,.5,1],xlabel='Predicted probability',ylabel='Observed proportion')
        ax.set_aspect('equal',adjustable='box');grid(ax);panel(ax,'ab'[j],label)
    ax=gs[2]
    for j,(s,suffix) in enumerate([('xuhui_oof',''),('xuhui_oof','_cal'),('fengxian',''),('fengxian','_cal')]):
        r=effects[(effects.cohort==s)&(effects.candidate=='OAF'+suffix)&(effects.reference=='RF_current'+suffix)&(effects.metric=='AUPRC')].iloc[0]
        interval(ax,r.difference,j,r.ci_low,r.ci_high,COLORS['OAF'] if suffix else '#75838D','s' if suffix else 'o')
    ax.axvline(0,color='#919CA5',lw=.8,ls=':')
    ax.set(yticks=range(4),yticklabels=['A · raw','A · cal.','B · raw','B · cal.'],ylim=(3.6,-.6),xlim=(-.014,.066),xticks=[0,.03,.06],xlabel='OAF − RF-current\nAUPRC difference')
    ax.set_box_aspect(1);grid(ax,'x');panel(ax,'c','Nested increments')
    legend=[Line2D([],[],color=COLORS['RF'],marker='o',ms=3,lw=1.7,label='RF-current'),Line2D([],[],color=COLORS['OAF'],marker='s',ms=3,lw=1.7,label='OAF'),Line2D([],[],color='#627381',ls='--',alpha=.55,label='Raw'),Line2D([],[],color='#627381',ls='-',label='Source-calibrated')]
    fig.legend(handles=legend,loc='upper center',bbox_to_anchor=(.52,.985),ncol=4,frameon=False,fontsize=7.4,columnspacing=1.5)
    pd.DataFrame(bins).to_csv(OUT/'figure5_calibration_bins.csv',index=False)
    save(fig,'Figure5')
    fig,axes=plt.subplots(1,2,figsize=(7.2,2.8));fig.subplots_adjust(left=.10,right=.98,bottom=.20,top=.83,wspace=.32)
    for ax,(s,label),letter in zip(axes,[('xuhui_oof','Site A'),('fengxian','Site B')],'ab'):
        z=pred[pred.cohort==s];w=1/z.patient_id.map(z.patient_id.value_counts()).to_numpy()
        for m in ['RF_current','OAF']:
            ax.hist(z[m],bins=np.linspace(0,1,11),weights=w/w.sum(),histtype='step',lw=1.5,color=COLORS['RF' if m=='RF_current' else 'OAF'],label='RF-current' if m=='RF_current' else 'OAF')
        ax.set(xlim=(0,1),xlabel='Raw predicted probability',ylabel='Patient-weighted fraction');grid(ax,'y');panel(ax,letter,label)
    axes[1].legend(frameon=False,fontsize=8)
    save(fig,'Supplementary_probability_support')

if __name__=='__main__':
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.glob('*.csv')}
    for f in [figure2,figure3,figure4,figure5]:
        print('Drawing',f.__name__,flush=True);f()
    assert hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.glob('*.csv')}
    (OUT/'input_hashes.json').write_text(json.dumps(hashes,indent=2))
    print('Complete: four figures in PNG, PDF and editable SVG. Archived input CSVs unchanged.')
