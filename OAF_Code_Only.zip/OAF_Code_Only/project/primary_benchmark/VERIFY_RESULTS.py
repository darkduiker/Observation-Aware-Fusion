"""Recompute saved metrics and paired bootstrap intervals; does not fit models."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for name in ["check_results.py", "check_tables.py", "check_bootstrap.py"]:
    subprocess.run([sys.executable,str(root/"code"/name)],check=True)
print("Saved-prediction verification passed.")
