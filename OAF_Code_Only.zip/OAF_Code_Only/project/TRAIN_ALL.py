"""Run full three-seed nested training with one Python file; results checkpoint each fold."""
from START import main
if __name__=='__main__':
    main('train_nested')
