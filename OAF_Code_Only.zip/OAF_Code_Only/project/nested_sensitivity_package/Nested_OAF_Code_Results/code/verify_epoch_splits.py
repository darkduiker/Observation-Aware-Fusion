"""Recover deterministic epoch-selection subsets and validate membership."""
from pathlib import Path
import json
import pandas as pd
from sklearn.model_selection import train_test_split
root=Path(__file__).resolve().parents[1];patients=pd.read_csv(root/'processed/patients.csv').set_index('patient_id');rows=[]
for f in sorted((root/'results/expert_cache').glob('*/complete.json')):
 a=json.loads(f.read_text());ids=a['fit_ids']
 if a['epoch_history']:
  y=patients.loc[ids,'outcome_binary'].to_numpy(int)
  tr,va=train_test_split(ids,test_size=.2,random_state=a['seed'],stratify=y)
  assert set(tr).isdisjoint(va) and set(tr)|set(va)==set(ids)
  rows.append({'expert_key':f.parent.name,'selection_training_ids':list(map(int,tr)),'epoch_validation_ids':list(map(int,va)),'epochs':a['epochs']})
 else:rows.append({'expert_key':f.parent.name,'fixed_epoch_refit':True,'fit_ids':ids,'epochs':a['epochs']})
(root/'results/epoch_split_verification.json').write_text(json.dumps(rows,indent=2))
print('Verified epoch selection/refit records:',len(rows))
