from START import *
def main():
 a=pd.read_csv(ROOT/'ensemble_predictions.csv');b=pd.read_csv(ROOT/'residual_ensemble.csv');keys=['patient_id','stage_id','target','cohort'];new=[x for x in b if x.startswith('residual_')];a=a.merge(b[keys+new],on=keys,validate='one_to_one')
 pairs=[(f'{m}_{k}','Global_AP') for m in ['obs','score','combined'] for k in ['brier','ranking']]+[(f'residual_{m}','Global_AP') for m in ['score','interaction','context']]+[('combined_ranking','score_ranking'),('combined_ranking_cal','score_ranking_cal'),('residual_interaction','residual_score'),('residual_interaction_cal','residual_score_cal')]
 rows=[];rng=np.random.default_rng(2004)
 for cohort,m in a.groupby('cohort'):
  y=m.target.to_numpy();ids,inv=np.unique(m.patient_id.to_numpy(),return_inverse=True);w=patient_weights(m.patient_id.to_numpy());draws=[]
  for t in range(1000):
   counts=np.bincount(rng.integers(0,len(ids),len(ids)),minlength=len(ids));wb=w*counts[inv]
   if len(np.unique(y[wb>0]))<2:continue
   draws.append(wb)
  for one,two in pairs:
   p=m[one].to_numpy();q=m[two].to_numpy();point=average_precision_score(y,p,sample_weight=w)-average_precision_score(y,q,sample_weight=w)
   ap=[];br=[]
   for wb in draws:
    ap.append(average_precision_score(y,p,sample_weight=wb)-average_precision_score(y,q,sample_weight=wb));br.append(np.average((p-y)**2-(q-y)**2,weights=wb))
   rows.append({'cohort':cohort,'candidate':one,'reference':two,'AP_difference':point,'AP_low':np.quantile(ap,.025),'AP_high':np.quantile(ap,.975),'Brier_difference':np.average((p-y)**2-(q-y)**2,weights=w),'Brier_low':np.quantile(br,.025),'Brier_high':np.quantile(br,.975),'bootstrap':1000})
  print('bootstrapped',cohort,flush=True)
 out=pd.DataFrame(rows);out.to_csv(ROOT/'paired_bootstrap.csv',index=False);print(out.round(5).to_string(index=False))
if __name__=='__main__':main()
