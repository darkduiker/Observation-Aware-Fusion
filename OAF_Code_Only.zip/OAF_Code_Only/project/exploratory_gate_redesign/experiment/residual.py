"""Source-selected logit residual stacking, exploratory alternative to convex OAF."""
from START import *
class Residual:
 def __init__(self,mode,reg):self.mode,self.reg=mode,reg
 def features(self,m):
  c,h,o,y,ids=arrays(m);delta=logit(np.clip(h,.001,.999))-logit(np.clip(c,.001,.999))
  x=delta[:,None]
  if self.mode=='interaction':x=np.column_stack([x,o*delta[:,None]])
  if self.mode=='context':x=np.column_stack([x,o,o*delta[:,None]])
  return x
 def fit(self,m):
  c,h,o,y,ids=arrays(m);w=patient_weights(ids);w/=w.sum();raw=self.features(m);self.mean=raw.mean(0);self.std=np.maximum(raw.std(0),.001)
  x=np.column_stack([np.ones(len(m)),np.clip((raw-self.mean)/self.std,-3,3)]);offset=logit(np.clip(c,.001,.999))
  def fun(b):
   z=offset+x@b;d=w*(expit(z)-y)
   return np.sum(w*(np.logaddexp(0,z)-y*z))+self.reg*np.dot(b,b),x.T@d+2*self.reg*b
  r=minimize(fun,np.zeros(x.shape[1]),jac=True,method='L-BFGS-B');self.b=r.x;return self
 def predict(self,m):
  x=np.column_stack([np.ones(len(m)),np.clip((self.features(m)-self.mean)/self.std,-3,3)])
  return expit(logit(np.clip(m.current.to_numpy(),.001,.999))+x@self.b)
def main():
 lookup=pd.read_csv(ROOT/'observation_lookup.csv');outs=[];select=[]
 (ROOT/'residual_protocol.json').write_text(json.dumps({'modes':['score','interaction','context'],'ridge':[.001,.01,.1],'selection':'source meta-validation pooled AP; no target selection','anchor':'RF logit offset','exploratory':True},indent=2))
 for seed in [2026,2027,2028]:
  for fold in range(5):
   dest=BASE/f'results_{seed}'/f'seed_{seed}'/f'fold_{fold}';out=pd.read_csv(ROOT/f'fold_{seed}_{fold}.csv');test=enrich(out.drop(columns=['history_weight']),lookup)
   cal=enrich(pd.read_csv(dest/'calibration_predictions.csv').drop(columns=['history_weight']),lookup);core=pd.read_csv(dest/'core_expert_oof.csv')
   for mode in ['score','interaction','context']:
    options=[]
    for reg in [.001,.01,.1]:
     pieces=[]
     for meta in range(3):
      tr=pd.read_csv(dest/f'meta_{meta}_expert_crossfit.csv');va=pd.read_csv(dest/f'meta_{meta}_validation_experts.csv');model=Residual(mode,reg).fit(tr)
      z=va[['patient_id','target']].copy();z['prediction']=model.predict(va);pieces.append(z)
     z=pd.concat(pieces);ap,br=score(z,z.prediction);options.append((ap,reg));select.append({'seed':seed,'fold':fold,'mode':mode,'ridge':reg,'source_AP':ap,'source_Brier':br})
    ap,reg=max(options,key=lambda t:(t[0],t[1]));model=Residual(mode,reg).fit(core);name='residual_'+mode;out[name]=model.predict(test);out[name+'_cal']=calibrate(cal,model.predict(cal),test,out[name].to_numpy())
   out.to_csv(ROOT/f'residual_fold_{seed}_{fold}.csv',index=False);outs.append(out);pd.DataFrame(select).to_csv(ROOT/'residual_source_selection.csv',index=False);print('residual completed',seed,fold,flush=True)
 raw=pd.concat(outs);cols=['RF_current','OAF','Global_AP','Fixed_half','Unshrunk_gate']+['residual_'+m for m in ['score','interaction','context']];cols += [n+'_cal' for n in cols]
 dev=raw[raw.cohort.eq('xuhui_oof')];ext=raw[raw.cohort.eq('fengxian')].groupby(['seed','patient_id','stage_id','target','cohort'],as_index=False)[cols].mean()
 ens=pd.concat([dev[['seed','patient_id','stage_id','target','cohort',*cols]],ext]).groupby(['patient_id','stage_id','target','cohort'],as_index=False)[cols].mean();ens.to_csv(ROOT/'residual_ensemble.csv',index=False)
 rows=[]
 for cohort,m in ens.groupby('cohort'):
  w=patient_weights(m.patient_id.to_numpy())
  for name in cols:
   ap,br=score(m,m[name]);rows.append({'cohort':cohort,'model':name,'AUPRC':ap,'AUROC':roc_auc_score(m.target,m[name],sample_weight=w),'Brier':br})
 pd.DataFrame(rows).to_csv(ROOT/'residual_metrics.csv',index=False);print(pd.DataFrame(rows).round(5).to_string(index=False))
if __name__=='__main__':main()
