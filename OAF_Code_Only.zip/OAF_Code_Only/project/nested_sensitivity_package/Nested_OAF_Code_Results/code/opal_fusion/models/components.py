"""Reusable neural components for irregular event streams."""

from __future__ import annotations

import math

import torch
from torch import nn


class _GradientReverseFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, inputs: torch.Tensor, weight: float) -> torch.Tensor:
        ctx.weight = weight
        return inputs.view_as(inputs)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        return -ctx.weight * grad_output, None


def gradient_reverse(inputs: torch.Tensor, weight: float = 1.0) -> torch.Tensor:
    return _GradientReverseFunction.apply(inputs, weight)


class ContinuousTimeEncoding(nn.Module):
    """Fourier features for elapsed or recency time in hours."""

    def __init__(self, output_dim: int, min_period: float = 0.25, max_period: float = 512.0) -> None:
        super().__init__()
        if output_dim < 4 or output_dim % 2:
            raise ValueError("output_dim must be an even integer >= 4")
        half = output_dim // 2
        periods = torch.logspace(math.log10(min_period), math.log10(max_period), half)
        self.register_buffer("angular_frequency", 2.0 * math.pi / periods, persistent=True)

    def forward(self, time_hours: torch.Tensor) -> torch.Tensor:
        phase = time_hours.unsqueeze(-1) * self.angular_frequency
        return torch.cat([torch.sin(phase), torch.cos(phase)], dim=-1)


class ResidualMLP(nn.Module):
    def __init__(self, dimension: int, dropout: float) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(dimension, 2 * dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(2 * dimension, dimension),
            nn.Dropout(dropout),
        )
        self.norm = nn.LayerNorm(dimension)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.norm(inputs + self.block(inputs))


class EventTokenizer(nn.Module):
    """Map value, identity, modality, time, stage, and QC into event tokens."""

    def __init__(
        self,
        n_variables: int,
        n_modalities: int,
        n_stages: int,
        dimension: int,
        time_dimension: int,
        n_time_quality: int = 6,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.variable_embedding = nn.Embedding(n_variables + 1, dimension, padding_idx=0)
        self.modality_embedding = nn.Embedding(n_modalities + 1, dimension, padding_idx=0)
        self.stage_embedding = nn.Embedding(n_stages, dimension)
        self.time_quality_embedding = nn.Embedding(n_time_quality, dimension)
        self.value_encoder = nn.Sequential(
            nn.Linear(3, dimension),
            nn.GELU(),
            nn.Linear(dimension, dimension),
        )
        self.recency_encoder = ContinuousTimeEncoding(time_dimension)
        self.elapsed_encoder = ContinuousTimeEncoding(time_dimension)
        self.time_projection = nn.Linear(2 * time_dimension, dimension)
        self.reliability_gate = nn.Sequential(
            nn.Linear(2, dimension // 2),
            nn.GELU(),
            nn.Linear(dimension // 2, 1),
            nn.Sigmoid(),
        )
        self.output = nn.Sequential(nn.LayerNorm(dimension), nn.Dropout(dropout))

    def forward(
        self,
        value: torch.Tensor,
        variable_id: torch.Tensor,
        modality_id: torch.Tensor,
        recency_hours: torch.Tensor,
        elapsed_hours: torch.Tensor,
        stage_id: torch.Tensor,
        time_quality_id: torch.Tensor,
        padding_mask: torch.Tensor,
    ) -> torch.Tensor:
        safe_value = torch.nan_to_num(value, nan=0.0, posinf=0.0, neginf=0.0)
        value_features = torch.stack(
            [safe_value, torch.sign(safe_value), torch.log1p(torch.abs(safe_value))],
            dim=-1,
        )
        stage = self.stage_embedding(stage_id).unsqueeze(1)
        time_features = torch.cat(
            [self.recency_encoder(recency_hours), self.elapsed_encoder(elapsed_hours)],
            dim=-1,
        )
        token = (
            self.value_encoder(value_features)
            + self.variable_embedding(variable_id)
            + self.modality_embedding(modality_id)
            + self.time_quality_embedding(time_quality_id)
            + self.time_projection(time_features)
            + stage
        )
        quality_is_valid = (time_quality_id != 0).to(token.dtype)
        gate_features = torch.stack(
            [torch.log1p(torch.clamp_min(recency_hours, 0.0)), quality_is_valid],
            dim=-1,
        )
        token = token * self.reliability_gate(gate_features)
        token = token.masked_fill(padding_mask.unsqueeze(-1), 0.0)
        return self.output(token)


class PolicyEncoder(nn.Module):
    def __init__(self, input_dimension: int, output_dimension: int, dropout: float) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.LayerNorm(input_dimension),
            nn.Linear(input_dimension, output_dimension),
            nn.GELU(),
            nn.Dropout(dropout),
            ResidualMLP(output_dimension, dropout),
        )

    def forward(self, policy_features: torch.Tensor) -> torch.Tensor:
        return self.network(torch.nan_to_num(policy_features, nan=0.0))

