from pathlib import Path
import json,argparse
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.special import logit
from fast_metric import Prepared
from fusion import patient_weights
from run_fully_nested import NAMES

def main(root,boot=5000):
 out=root/'evaluation';out.mkdir(exist_ok=True);allpred=[];auditrows=[]
 for seed in [2026,2027,2028]:
  r=root/f'results_{seed}'
  assert (r/'RUN_COMPLETE.json').exists(),str(r)
  d=pd.read_csv(r/'predictions_by_seed.csv');allpred.append(d)
  for fold in range(5):
   a=json.loads((r/f'seed_{seed}/fold_{fold}/complete.json').read_text())
   core=set(a['core_training_ids']);cal=set(a['calibration_ids']);val=set(a['outer_validation_ids']);ext=set(a['target_ids'])
   assert core.isdisjoint(cal|val|ext) and cal.isdisjoint(val|ext) and val.isdisjoint(ext)
   for m in a['meta_folds']:
    mt=set(m['training_ids']);mv=set(m['validation_ids']);assert mt|mv==core and mt.isdisjoint(mv)
    assert set(m['validation_expert_fit_ids'])==mt
    for fit in m['expert_crossfits']:
     tr=set(fit['fit_ids']);pr=set(fit['prediction_ids']);assert tr.isdisjoint(pr) and tr|pr==mt and (tr|pr).isdisjoint(mv|cal|val|ext)
   auditrows.append({'seed':seed,'fold':fold,'source_core':len(core),'source_calibration':len(cal),'outer_validation':len(val),'target':len(ext),'lambda_Brier':a['selected_strength'],'lambda_AP':a['selected_AP_strength'],'global_AP_weight':a['selected_global_AP_weight'],'all_patient_separations_verified':True})
 raw=pd.concat(allpred,ignore_index=True);cols=NAMES+[n+'_cal' for n in NAMES];keys=['patient_id','stage_id','target','cohort']
 for seed,d in raw.groupby('seed'):
  assert len(d)==1596 and d.patient_id.nunique()==854
 ens=raw.groupby(keys,as_index=False)[cols].mean();assert len(ens)==1596
 raw.to_csv(out/'predictions_by_seed.csv',index=False);ens.to_csv(out/'ensemble_predictions.csv',index=False);pd.DataFrame(auditrows).to_csv(out/'patient_split_verification.csv',index=False)
 points=[]
 for seed,d in [('ensemble',ens)]+[(str(seed),d) for seed,d in raw.groupby('seed')]:
  for site,z in d.groupby('cohort'):
   w=patient_weights(z.patient_id.to_numpy());y=z.target.to_numpy()
   for n in cols:
    v=Prepared(y,z[n].to_numpy(),z[n].to_numpy()).values(w)
    points.append({'seed':seed,'cohort':site,'model':n,'AUPRC':v[0],'AUROC':v[1],'Brier':v[2]})
 metrics=pd.DataFrame(points);metrics.to_csv(out/'metrics_by_seed_and_ensemble.csv',index=False)
 pairs=[];calrows=[];rng=np.random.default_rng(20261004)
 for site,z in ens.groupby('cohort'):
  ids,inv,cnt=np.unique(z.patient_id,return_inverse=True,return_counts=True);w=1/cnt[inv];y=z.target.to_numpy()
  cache={n:Prepared(y,z[n].to_numpy(),z[n].to_numpy()) for n in cols};draw={n:np.empty((boot,3)) for n in cols}
  for b in range(boot):
   ww=w*rng.multinomial(len(ids),np.ones(len(ids))/len(ids))[inv]
   for n in cols:draw[n][b]=cache[n].values(ww)[:3]
  for candidate in ['OAF','OAF_AP','OAF_cal','OAF_AP_cal']:
   suffix='_cal' if candidate.endswith('_cal') else ''
   refs=['RF_current','Fixed_half','Global_weight','Unshrunk_gate','Global_AP']
   if candidate.startswith('OAF_AP'):refs+=['OAF']
   for r in refs:
    ref=r+suffix;pt=cache[candidate].values(w)[:3]-cache[ref].values(w)[:3];di=draw[candidate]-draw[ref]
    for j,m in enumerate(['AUPRC','AUROC','Brier']):
     lo,hi=np.quantile(di[:,j],[.025,.975]);pairs.append({'cohort':site,'candidate':candidate,'reference':ref,'metric':m,'difference':pt[j],'ci_low':lo,'ci_high':hi,'bootstrap':boot})
  for n in cols:
   x=logit(np.clip(z[n],1e-6,1-1e-6))
   def objective(a):
    t=a[0]+a[1]*x;return np.average(np.logaddexp(0,t)-y*t,weights=w)
   f=minimize(objective,[0,1],method='BFGS');calrows.append({'cohort':site,'model':n,'intercept':f.x[0],'slope':f.x[1],'optimizer_success':bool(f.success)})
 pd.DataFrame(pairs).to_csv(out/'paired_ensemble_bootstrap.csv',index=False);pd.DataFrame(calrows).to_csv(out/'calibration_diagnostics.csv',index=False)
 (out/'EVALUATION_COMPLETE.json').write_text(json.dumps({'seeds':[2026,2027,2028],'folds_verified':len(auditrows),'patient_count':854,'landmarks':1596,'bootstrap':boot,'uncertainty':'patient sampling conditional on three seed-averaged fitted model sets; no independent validation','target_selection':False},indent=2))
 print(metrics[metrics.seed.eq('ensemble')].round(5).to_string(index=False));print(pd.DataFrame(pairs).query('metric=="AUPRC" and not candidate.str.endswith("_cal")',engine='python').round(5).to_string(index=False))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--bootstrap',type=int,default=5000);a=ap.parse_args();main(a.root,a.bootstrap)
