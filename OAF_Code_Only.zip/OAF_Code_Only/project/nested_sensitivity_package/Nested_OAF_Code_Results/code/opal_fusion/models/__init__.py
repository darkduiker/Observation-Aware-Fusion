"""Continuous time encoding from the supplied model source."""
