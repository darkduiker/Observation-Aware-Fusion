"""Cached score order for weighted AP/AUROC; ties use shared thresholds."""
import numpy as np
class Prepared:
 def __init__(self,y,p,baseline):
  self.y=np.asarray(y);self.p=np.asarray(p);self.response=abs(self.p-baseline)
  self.order=np.argsort(-self.p,kind='mergesort');s=self.p[self.order]
  self.end=np.r_[np.flatnonzero(np.diff(s)),len(s)-1]
 def values(self,w):
  yp=self.y[self.order];sw=w[self.order]
  tp=np.cumsum(sw*yp)[self.end];fp=np.cumsum(sw*(1-yp))[self.end]
  ap=np.sum(np.diff(np.r_[0,tp])/(tp[-1]) * np.divide(tp,tp+fp,out=np.zeros_like(tp),where=tp+fp>0))
  t=np.r_[0,tp/tp[-1]];f=np.r_[0,fp/fp[-1]]
  auc=np.sum(np.diff(f)*(t[1:]+t[:-1])/2)
  return np.array([ap,auc,np.average((self.y-self.p)**2,weights=w),np.average(self.response,weights=w)])
