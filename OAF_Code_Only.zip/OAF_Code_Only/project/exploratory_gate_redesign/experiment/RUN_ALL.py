"""One Python entry point for gate redesign, residual controls and paired evaluation."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for script in ['START.py','residual.py','evaluate.py']:
 subprocess.run([sys.executable,str(root/script)],check=True,cwd=root.parent)
print('Complete: metrics.csv, residual_metrics.csv, paired_bootstrap.csv')
