from pathlib import Path
import pandas as pd,numpy as np,json
root=Path(__file__).resolve().parents[1];out=root/'results'
m=pd.read_csv(out/'metrics.csv');effects=pd.read_csv(out/'paired_bootstrap.csv');diag=pd.read_csv(out/'calibration_diagnostics.csv');splits=pd.read_csv(out/'split_validation.csv')

def table(df):
 return '| '+' | '.join(df.columns)+' |\n| '+' | '.join(['---']*len(df.columns))+' |\n'+'\n'.join('| '+' | '.join(str(x) for x in row)+' |' for row in df.itertuples(index=False,name=None))

def combined(cal):
 rows=[]
 for name in ['RF_current','GRUD','Fixed_half','Global_weight','Unshrunk_gate','OAF']:
  row={'Model':name}
  for site,label in [('xuhui_oof','Site A OOF'),('fengxian','Site B')]:
   x=m[(m.cohort==site)&(m.model==name+('_cal' if cal else ''))].iloc[0]
   row[label+' AUROC']=f'{x.AUROC:.4f}';row[label+' AUPRC']=f'{x.AUPRC:.4f}';row[label+' Brier']=f'{x.Brier:.4f}'
  rows.append(row)
 return pd.DataFrame(rows)

show=effects[(effects.metric=='AUPRC')&effects.contrast.isin(['OAF - RF_current','OAF - Fixed_half','OAF - Global_weight','OAF - Unshrunk_gate','OAF_cal - RF_current_cal','OAF_cal - Fixed_half_cal','OAF_cal - Global_weight_cal','OAF_cal - Unshrunk_gate_cal'])].copy()
show['difference [95% interval]']=show.apply(lambda x:f'{x.difference:+.4f} [{x.ci_low:+.4f}, {x.ci_high:+.4f}]',axis=1)
cal=effects[(effects.metric=='Brier')&effects.contrast.str.contains('_cal - ')].copy();cal['difference [95% interval]']=cal.apply(lambda x:f'{x.difference:+.4f} [{x.ci_low:+.4f}, {x.ci_high:+.4f}]',axis=1)
report='''# 完整嵌套 OAF 验证与独立校准：结果

本轮已重新训练临床 RF＋GRU-D 专家，不是对旧预测加一层校准。采用 5 个冻结患者级外层折，种子 2026。共 65 对 RF/GRU-D 专家；GRU-D 早停选择与最终拟合分开。使用原有编码、阶段首次查询和患者等权指标；736 名徐汇患者 / 1,378 个查询，118 名奉贤患者 / 218 个查询。

## 验证流程

每个外层训练池独立留出 20% 患者用于校准。这些患者不进入预处理、专家训练、早停选择、门控拟合和门控强度选择。其余患者作 3 折门控选择；每个门控训练折内部又重新生成 3 折专家 OOF 预测。用于门控选择折的专家仅在该折之外训练。完成选择后，门控在整个核心训练池的专家 OOF 预测上拟合，再以核心训练池拟合最终专家。

门控网格为 0、0.01、0.05、0.2、1，以门控选择折中的患者等权 Brier 选择，平分时选更强收缩。所有融合对照使用相同专家和患者集合。校准映射在专门留出的开发院区患者上拟合，采用非负斜率的加权逻辑校准，含 1e-4 L2 正则；各模型分别拟合校准器。校准映射与专家均不在奉贤拟合或调参。

外层验证患者完全不参与以上选择。奉贤预测为 5 个外层模型的概率均值。奉贤此前被检视过，因此仍是探索性跨院区评价，不是新独立验证。

独立校准占用了部分训练患者，且内层随机划分与旧实验不同。因此旧版和本轮指标的差异不能单独归因于“修复嵌套”。公平比较应在本轮内部进行。

## 未校准结果

'''+table(combined(False))+'''

## 开发院区独立留出校准后

'''+table(combined(True))+'''

Brier 越低越好。AUROC/AUPRC 使用分娩干预为正类。单个外层模型的正斜率校准不改变排序，但各折/模型使用不同校准器，汇总 OOF 或平均外层概率后的排序可改变；因此汇总 AP 有变化并不自动意味着实现错误。

## OAF 的配对 AUPRC 增量

'''+table(show[['cohort','contrast','difference [95% interval]']])+'''

## 校准本身的 Brier 变化（负值表示改善）

'''+table(cal[['cohort','contrast','difference [95% interval]']])+'''

完整 AUROC/Brier 对比见 paired_bootstrap.csv；校准 intercept/slope 与曲线数据见 calibration_diagnostics.csv / calibration_bins.csv。校准诊断在最终评价预测上估计，只用于描述，不用于更新或重新校准测试预测。

## 解释边界

- 本轮完整隔离了门控选择折与专家拟合，并独立留出了校准患者；患者集合交叉核验见 split_validation.csv 和各折 complete.json。
- 配对区间采用 5,000 次患者簇重采样，条件于已经拟合的预测，不包含重训练不确定性；多个对照未做多重比较校正。
- 这是完整五折的单种子验证，不可写成“三种子稳定性已验证”。旧三种子结果来自不同训练协议，不能合并作为本轮重复实验。
- 开发院区校准不保证跨院区校准改善；校准不能修复所有排序失误或观察策略变化。
- 这一轮不重新计算旧 A–E 分解表，不改变原始结局或变量定义，也没有生成新的干预决策时间。

## 文件与复跑

START.py 运行完整嵌套训练与评价。训练结果逐折、逐专家保存。代码及当前协议使用新目录，原稿和旧实验包保留。临床原始表、处理表、模型和患者级结果仅用于授权研究；公开代码时应移除这些敏感文件。
'''
head='**结论：完整嵌套验证已完成，OAF 的判别增益仍应按条件性结果解释。**\n\n'
for site,title in [('xuhui_oof','徐汇'),('fengxian','奉贤')]:
 x=effects[(effects.cohort==site)&effects.contrast.eq('OAF - RF_current')&effects.metric.eq('AUPRC')].iloc[0]
 z=effects[(effects.cohort==site)&effects.contrast.eq('OAF_cal - RF_current_cal')&effects.metric.eq('Brier')].iloc[0]
 head+=f'- {title}：未校准 OAF 相对 RF 的 AP 差值 {x.difference:+.4f}（{x.ci_low:+.4f} 至 {x.ci_high:+.4f}）；校准后 OAF 相对校准后 RF 的 Brier 差值 {z.difference:+.4f}（{z.ci_low:+.4f} 至 {z.ci_high:+.4f}）。\n'
head+='\n开发院区 OAF 校准斜率由 1.5586 接近到 0.9994；奉贤校准后仍为 1.9009，截距为 0.8161，因此跨院区概率校准问题并未完全消除。\n'
head+='\n若 AP 区间跨零，不能宣称稳定判别优势；接近零的区间边界也不应作为强优越性的依据。所有五折选择了网格内最强收缩 λ=1，提示训练内选择偏向保守使用历史。对简单融合与无收缩门控的比较仍必须完整呈现。\n\n'
report=report.replace('## 验证流程',head+'## 验证流程',1)
(root/'FINDINGS.md').write_text(report)
# Short English methods/results text, grounded only in this run.
text='''Fully nested validation and independent calibration. We retained the five patient-grouped outer folds and reserved 20% of each outer training pool for calibration. Calibration patients were excluded from preprocessing, expert development, epoch selection, and gate selection. Within the remaining development pool, gate strength was selected in three patient-grouped folds. Expert cross-fitting was regenerated within each gate-training subset, ensuring that gate-selection patients did not contribute to the experts that generated their validation scores. The final gate was fitted to cross-fitted expert scores from the core development pool. Model-specific monotone logistic calibration maps were then estimated on the independent source-campus calibration patients and applied without refitting to the outer validation patients and the exploratory target campus. We evaluated one random seed with patient-equal metrics and 5,000 paired patient-cluster bootstrap resamples conditional on the fitted predictions.\n\n'''
for site,title in [('xuhui_oof','development-campus OOF'),('fengxian','exploratory target-campus')]:
 a=m[(m.cohort==site)&m.model.eq('OAF')].iloc[0];b=m[(m.cohort==site)&m.model.eq('OAF_cal')].iloc[0]
 x=effects[(effects.cohort==site)&effects.contrast.eq('OAF - RF_current')&effects.metric.eq('AUPRC')].iloc[0]
 text+=f'For {title} predictions, uncalibrated OAF achieved AUROC {a.AUROC:.4f}, AP {a.AUPRC:.4f}, and Brier score {a.Brier:.4f}. Its paired AP difference from current RF was {x.difference:+.4f} (95% interval {x.ci_low:+.4f} to {x.ci_high:+.4f}). Following source-only calibration, OAF AP and Brier score were {b.AUPRC:.4f} and {b.Brier:.4f}, respectively. '
text+='\n\nThe smaller expert-training pool and different inner allocations prevent attributing changes from earlier experiments solely to the nesting correction. These results must not be pooled with the earlier three-seed experiment.\n'
(root/'METHODS_RESULTS_INSERT.md').write_text(text)
print('Findings written.')
