"""Column roles for the supplied labor workbook.

The schema is explicit because several columns that look dynamic do not have a
reliable timestamp. Untimestamped clinical updates are excluded from landmark
histories by default to avoid future-information leakage.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


PATIENT_ID_COLUMN = "编号"
OUTCOME_COLUMN = "分娩结局（0-产钳/1-自然/2-顺转剖）"

SITE_RANGES = {
    "xuhui": (1, 738),
    "fengxian": (739, 856),
    # These records do not represent one defensible acquisition domain.
    # Keep them auditable but exclude them from the locked two-site analysis.
    "mixed_source_excluded": (857, 922),
}

BASELINE_COLUMNS = (
    "年龄",
    "身高（m）",
    "体重(kg)",
    "产时BMI",
    "孕周",
    "孕次",
    "产次",
    "既往剖宫产（0/1）",
    "合并症（妊糖-1；妊高-2；胎膜早破-3；蛋白尿-4；囊肿-5；妊贫-6；其他-7；无-0）",
    "既往盆底或骨盆手术（0/1）",
    "双顶径（mm）",
    "精神心理（爱丁堡）",
    "入口前后径",
    "耻骨弓角度(度)",
)

# These variables may be recorded or updated during labor but lack a reliable
# per-value timestamp in the workbook. They are retained for auditing and are
# excluded from causal landmark features by default.
UNTIMESTAMPED_DYNAMIC_COLUMNS = (
    "胎膜状态（0-自破/1-人破）",
    "羊水颜色（0-清、1-I度、2-II度、3-III度、4-血性）",
    "发热（否-0,；是-1）",
    "胎监判读结果（0=正常；1-可疑或异常",
)


@dataclass(frozen=True)
class EventSpec:
    name: str
    value_column: str
    time_column: str
    value_kind: Literal["continuous", "categorical"] = "continuous"
    modality: str = "ultrasound"
    enabled: bool = True


EVENT_SPECS = (
    EventSpec("pelvic_inlet_ap", "入口前后径", "入口前后径时间"),
    EventSpec("pubic_arch_angle", "耻骨弓角度(度)", "耻骨弓角度时间"),
    EventSpec("fetal_position", "胎方位", "胎方位时间", "categorical"),
    EventSpec("midline_angle", "中线角(度)", "中线角时间"),
    EventSpec("spine_occiput_angle", "脊柱枕骨角(度)", "脊柱枕骨角时间"),
    EventSpec("chin_chest_angle", "颏胸角(度)", "颏胸角时间"),
    EventSpec("cervical_length", "宫颈管长度(cm)", "宫颈管长度时间"),
    EventSpec("cervical_effacement", "宫颈管消退", "宫颈管消退时间"),
    EventSpec("aop", "AOP(度)", "AOP时间"),
    EventSpec("head_station", "胎头先露(cm)", "胎头先露时间"),
    # Nearly every non-empty TOCO cell is a placeholder in the supplied file.
    # Retain its QC counts but disable it as a numerical event by default.
    EventSpec("toco_snapshot", "宫缩TOCO", "宫缩TOCO时间", enabled=False),
    EventSpec("progression_distance", "进展距离(cm)", "进展距离时间"),
    EventSpec("head_direction_angle", "胎头方向角(度)", "胎头方向角时间"),
    EventSpec("hpd_recorded", "HPD(mm)", "HPD时间"),
    EventSpec("cervical_dilation", "宫颈扩张(cm)", "宫颈扩张时间"),
)

FETAL_POSITION_VOCAB = {
    "左枕横": 1,
    "左枕前": 2,
    "右枕横": 3,
    "左枕后": 4,
    "右枕后": 5,
    "右枕前": 6,
    "正枕前": 7,
    "正枕后": 8,
}

PLACEHOLDERS = {"", "---", "-- --", "--", "—", "nan", "none", "null"}


def site_from_patient_id(patient_id: int) -> str:
    for site, (lower, upper) in SITE_RANGES.items():
        if lower <= patient_id <= upper:
            return site
    return "unknown"


def stage_from_dilation(value: float) -> str | None:
    if value < 4.0:
        return "lt4"
    if 4.0 <= value < 6.0:
        return "4to6"
    if 6.0 <= value <= 10.0:
        return "6to10"
    return None

# Fixed clinical vocabulary, never inferred from evaluation patients.
POSITION_CHANNELS = tuple(f"fetal_position_{k}" for k in range(9))
MODEL_EVENT_SPECS = tuple(t for spec in EVENT_SPECS for t in ([EventSpec(n, spec.value_column, spec.time_column) for n in POSITION_CHANNELS] if spec.name == "fetal_position" else [spec]))
