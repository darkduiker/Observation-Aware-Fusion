"""Run with Python/VS Code or double-click: choose the authorized workbook."""
from pathlib import Path
import argparse,importlib.util,subprocess,sys,json,shutil

def main():
    root=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser()
    ap.add_argument('--workbook',type=Path);ap.add_argument('--processed',type=Path)
    ap.add_argument('--seeds',type=int,nargs='+',default=[2026,2027,2028])
    ap.add_argument('--epochs',type=int,default=60);ap.add_argument('--bootstrap',type=int,default=5000)
    args=ap.parse_args()
    modules={'numpy':'numpy','pandas':'pandas','scipy':'scipy','sklearn':'scikit-learn','openpyxl':'openpyxl','matplotlib':'matplotlib','lightgbm':'lightgbm'}
    missing=[package for module,package in modules.items() if importlib.util.find_spec(module) is None]
    if missing:subprocess.run([sys.executable,'-m','pip','install',*missing],check=True)
    if importlib.util.find_spec('torch') is None:
        subprocess.run([sys.executable,'-m','pip','install','torch','--index-url','https://download.pytorch.org/whl/cpu'],check=True)
    sys.path.insert(0,str(root/'code'))
    import pandas as pd
    from opal_fusion.data.labor_workbook import LaborWorkbookLoader
    processed=args.processed
    if processed is None:
        workbook=args.workbook
        if workbook is None:
            candidates=list(root.glob('*.xlsx'))
            if len(candidates)==1:workbook=candidates[0]
            else:
                try:
                    import tkinter as tk
                    from tkinter.filedialog import askopenfilename
                    ui=tk.Tk();ui.withdraw()
                    chosen=askopenfilename(title='选择原始产时超声工作簿',filetypes=[('Excel workbook','*.xlsx')])
                    ui.destroy();workbook=Path(chosen) if chosen else None
                except Exception:workbook=None
        if workbook is None or not workbook.exists():
            raise FileNotFoundError('请将原工作簿放在 START.py 旁边，或使用 --workbook 指定路径。')
        processed=root/'processed_private';processed.mkdir(exist_ok=True)
        bundle=LaborWorkbookLoader(workbook).load()
        bundle.patients.to_csv(processed/'patients.csv',index=False)
        bundle.events.to_csv(processed/'events.csv',index=False)
        bundle.landmarks.to_csv(processed/'landmarks.csv',index=False)
        ref=pd.read_csv(root/'code/reference_folds.csv')
        eligible=bundle.patients.loc[bundle.patients.eligible&bundle.patients.site.eq('xuhui'),'patient_id']
        if set(ref.patient_id)!=set(eligible):
            raise ValueError('输入工作簿患者编号与本轮冻结队列不符；请核对数据版本和院区映射。')
        ref.to_csv(processed/'xuhui_folds.csv',index=False)
        (processed/'manifest.json').write_text(json.dumps(bundle.summary(),ensure_ascii=False,indent=2))
    settings={'seeds':args.seeds,'epochs':args.epochs,'representation':'nominal_position_22_channels'}
    settings_file=root/'RUN_SETTINGS.json'
    if settings_file.exists() and json.loads(settings_file.read_text())!=settings:
        raise ValueError('训练参数与缓存不一致。请使用新的解压目录重新运行，避免混合旧结果。')
    settings_file.write_text(json.dumps(settings,indent=2))
    subprocess.run([sys.executable,str(root/'code/run_nested.py'),'--processed',str(processed),
                    '--seeds',*map(str,args.seeds),'--epochs',str(args.epochs)],check=True,cwd=root)
    subprocess.run([sys.executable,str(root/'code/evaluate.py'),'--bootstrap',str(args.bootstrap)],check=True,cwd=root)
    subprocess.run([sys.executable,str(root/'code/run_baselines.py'),'--processed',str(processed),
                    '--seeds',*map(str,args.seeds),'--epochs',str(args.epochs)],check=True,cwd=root)
    subprocess.run([sys.executable,str(root/'code/six_model_results.py'),'--bootstrap',str(args.bootstrap)],check=True,cwd=root)
    subprocess.run([sys.executable,str(root/'code/extra_analysis.py')],check=True,cwd=root)
    subprocess.run([sys.executable,str(root/'code/site_diagnostic.py')],check=True,cwd=root)
    if args.seeds==[2026,2027,2028] and args.epochs==60:
        for script in ['common_decomposition.py','evaluate_common.py','report_common.py']:
            subprocess.run([sys.executable,str(root/'code'/script)],check=True,cwd=root)
    subprocess.run([sys.executable,str(root/'code/method_figure.py')],check=True,cwd=root)
    subprocess.run([sys.executable,str(root/'code/redraw_six_figure.py')],check=True,cwd=root)
    print('完成。模型结果在 results/；共同实验在 common_experiment_verified/。')

if __name__=='__main__':
    try:main()
    except Exception:
        import traceback;traceback.print_exc()
        if sys.stdin.isatty():input('运行失败，完整错误已显示。按 Enter 退出。')
        raise
