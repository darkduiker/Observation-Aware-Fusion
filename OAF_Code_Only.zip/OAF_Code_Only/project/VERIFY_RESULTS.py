"""Verify saved results without fitting experts or requiring PyTorch."""
from pathlib import Path
import json,sys,importlib.util,subprocess
ROOT=Path(__file__).resolve().parent
def main():
    deps={'numpy':'numpy','pandas':'pandas','sklearn':'scikit-learn'}
    missing=[pkg for module,pkg in deps.items() if importlib.util.find_spec(module) is None]
    if missing:subprocess.run([sys.executable,'-m','pip','install',*missing],check=True)
    import numpy as np,pandas as pd
    from sklearn.metrics import average_precision_score,roc_auc_score,brier_score_loss
    sys.path.insert(0,str(ROOT/'nested_validation/code'))
    from fast_metric import Prepared
    output=ROOT/'verification/replayed';output.mkdir(exist_ok=True)
    p=ROOT/'nested_validation/evaluation'
    d=pd.read_csv(p/'ensemble_predictions.csv')
    expected=pd.read_csv(p/'metrics_by_seed_and_ensemble.csv');expected=expected[expected.seed.eq('ensemble')]
    assert len(d)==1596 and d.patient_id.nunique()==854
    rec=[]
    names=[c for c in d if c not in ['patient_id','stage_id','target','cohort']]
    for site,z in d.groupby('cohort'):
        cnt=z.patient_id.value_counts();w=1/z.patient_id.map(cnt).to_numpy();y=z.target.to_numpy()
        for name in names:
            v=[average_precision_score(y,z[name],sample_weight=w),roc_auc_score(y,z[name],sample_weight=w),brier_score_loss(y,z[name],sample_weight=w)]
            for m,x in zip(['AUPRC','AUROC','Brier'],v):
                ref=float(expected.loc[expected.cohort.eq(site)&expected.model.eq(name),m].iloc[0]);assert abs(x-ref)<1e-10
                rec.append({'cohort':site,'model':name,'metric':m,'value':x,'reference':ref,'error':abs(x-ref)})
    pd.DataFrame(rec).to_csv(output/'recomputed_metrics.csv',index=False)
    # Check all source/core/calibration/meta-validation/target patient separations.
    records=[]
    for seed in [2026,2027,2028]:
        for fold in range(5):
            a=json.loads((ROOT/f'nested_validation/results_{seed}/seed_{seed}/fold_{fold}/complete.json').read_text())
            core=set(a['core_training_ids']);cal=set(a['calibration_ids']);val=set(a['outer_validation_ids']);ext=set(a['target_ids'])
            assert core.isdisjoint(cal|val|ext) and cal.isdisjoint(val|ext) and val.isdisjoint(ext)
            assert core|cal==set(a['outer_training_ids'])
            for mf in a['meta_folds']:
                tr=set(mf['training_ids']);va=set(mf['validation_ids']);assert tr.isdisjoint(va) and tr|va==core
                assert set(mf['validation_expert_fit_ids'])==tr
                for f in mf['expert_crossfits']:
                    fit=set(f['fit_ids']);pr=set(f['prediction_ids']);assert fit.isdisjoint(pr) and fit|pr==tr and (fit|pr).isdisjoint(va|cal|val|ext)
            records.append({'seed':seed,'fold':fold,'verified':True})
    pd.DataFrame(records).to_csv(output/'patient_split_checks.csv',index=False)
    # Recompute the two key nested contrasts using the frozen 5000-draw protocol.
    # The original RNG advances across every procedure and contrast site; process sites
    # in the same order and use all patient draws before moving to the next site.
    rng=np.random.default_rng(20261004);rows=[]
    for site,z in d.groupby('cohort'):
        ids,inv,count=np.unique(z.patient_id,return_inverse=True,return_counts=True);w=1/count[inv];y=z.target.to_numpy()
        cols=['OAF','RF_current','OAF_cal','RF_current_cal','Global_AP']
        cache={n:Prepared(y,z[n].to_numpy(),z[n].to_numpy()) for n in cols};draws={n:np.empty((5000,3)) for n in cols}
        for b in range(5000):
            ww=w*rng.multinomial(len(ids),np.full(len(ids),1/len(ids)))[inv]
            for n in cols:draws[n][b]=cache[n].values(ww)[:3]
        for a,b in [('OAF','RF_current'),('OAF_cal','RF_current_cal'),('OAF','Global_AP')]:
            point=cache[a].values(w)[:3]-cache[b].values(w)[:3];delta=draws[a]-draws[b]
            for j,m in enumerate(['AUPRC','AUROC','Brier']):
                lo,hi=np.quantile(delta[:,j],[.025,.975]);rows.append({'cohort':site,'candidate':a,'reference':b,'metric':m,'difference':point[j],'ci_low':lo,'ci_high':hi,'bootstrap':5000})
    replay=pd.DataFrame(rows);replay.to_csv(output/'recomputed_key_intervals.csv',index=False)
    saved=pd.read_csv(p/'paired_ensemble_bootstrap.csv')
    joined=replay.merge(saved,on=['cohort','candidate','reference','metric'],suffixes=('_replay','_saved'))
    assert len(joined)==len(replay)
    for col in ['difference','ci_low','ci_high']:assert np.max(abs(joined[col+'_replay']-joined[col+'_saved']))<1e-10
    (output/'COMPLETE.json').write_text(json.dumps({'patients':854,'landmarks':1596,'patient_folds_verified':15,'metrics_verified':len(rec),'key_intervals_verified':len(replay),'fitted_models_retrained':False},indent=2))
    print('Verified 854 patients, 1596 landmarks, 15 outer patient folds, all nested metric values and key paired intervals.')
    print('No expert retraining was performed. To train, edit MODE in START.py to train_nested, using Python 3.12 and requirements.txt.')
if __name__=='__main__':main()
