from pathlib import Path
import json,argparse
import numpy as np,pandas as pd
from scipy.special import logit,expit
from scipy.optimize import minimize
from sklearn.metrics import average_precision_score,roc_auc_score,brier_score_loss,balanced_accuracy_score
from fusion import patient_weights
from fast_metric import Prepared
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

NAMES=['RF_current','GRUD','Fixed_half','Global_weight','Unshrunk_gate','OAF']

def main(root,boot):
 out=root/'results';d=pd.read_csv(out/'ensemble_predictions.csv');assert len(d)==1596
 records=[]
 for f in sorted(out.glob('seed_*/fold_*/complete.json')):
  a=json.loads(f.read_text());core=set(a['core_training_ids']);cal=set(a['calibration_ids']);val=set(a['outer_validation_ids']);ext=set(a['target_ids'])
  assert core.isdisjoint(cal|val|ext) and cal.isdisjoint(val|ext) and val.isdisjoint(ext)
  assert core|cal==set(a['outer_training_ids'])
  for meta in a['meta_folds']:
   mt=set(meta['training_ids']);mv=set(meta['validation_ids']);assert mt|mv==core and mt.isdisjoint(mv)
   assert set(meta['validation_expert_fit_ids'])==mt
   for x in meta['expert_crossfits']:
    fit=set(x['fit_ids']);pr=set(x['prediction_ids']);assert fit.isdisjoint(pr) and fit|pr==mt and (fit|pr).isdisjoint(mv|cal|val|ext)
  records.append({'seed':f.parent.parent.name,'fold':f.parent.name,'disjoint':True,'core':len(core),'calibration':len(cal),'validation':len(val),'selected_strength':a['selected_strength']})
 pd.DataFrame(records).to_csv(out/'split_validation.csv',index=False)
 foldpred=pd.read_csv(out/'fold_predictions.csv')
 gate_stats=foldpred.groupby(['cohort','fold']).history_weight.agg(['mean','std','min','max']).reset_index()
 gate_stats.to_csv(out/'gate_weight_summary.csv',index=False)
 comparisons=[('OAF','RF_current'),('OAF','Fixed_half'),('OAF','Global_weight'),('OAF','Unshrunk_gate'),('OAF_cal','RF_current_cal'),('OAF_cal','Fixed_half_cal'),('OAF_cal','Global_weight_cal'),('OAF_cal','Unshrunk_gate_cal')]+[(n+'_cal',n) for n in NAMES]
 columns=NAMES+[n+'_cal' for n in NAMES];rows=[];rng=np.random.default_rng(94022);fits=[];calpoints=[]
 for site,g in d.groupby('cohort'):
  ids,inv,counts=np.unique(g.patient_id,return_inverse=True,return_counts=True);w=1/counts[inv];y=g.target.to_numpy()
  cache={n:Prepared(y,g[n].to_numpy(),g[n].to_numpy()) for n in columns};draws={n:[] for n in columns}
  for i in range(boot):
   ww=w*rng.multinomial(len(ids),np.full(len(ids),1/len(ids)))[inv]
   for n in columns:draws[n].append(cache[n].values(ww)[:3])
  for left,right in comparisons:
   pts=cache[left].values(w)[:3]-cache[right].values(w)[:3];diff=np.asarray(draws[left])-draws[right]
   for j,m in enumerate(['AUPRC','AUROC','Brier']):
    lo,hi=np.quantile(diff[:,j],[.025,.975]);rows.append({'cohort':site,'contrast':left+' - '+right,'metric':m,'difference':pts[j],'ci_low':lo,'ci_high':hi,'bootstrap':boot})
  for name in columns:
   x=logit(np.clip(g[name].to_numpy(),1e-6,1-1e-6))
   def objective(b):
    z=b[0]+b[1]*x;return np.average(np.logaddexp(0,z)-y*z,weights=w)
   fit=minimize(objective,[0.,1.],method='BFGS')
   fits.append({'cohort':site,'model':name,'calibration_intercept':fit.x[0],'calibration_slope':fit.x[1],'optimizer_success':bool(fit.success)})
   # Weighted bins constructed from prediction quantiles. Descriptive only.
   grp=pd.qcut(g[name],q=6,duplicates='drop',labels=False)
   for k in sorted(grp.dropna().unique()):
    ix=(grp==k).to_numpy();calpoints.append({'cohort':site,'model':name,'bin':int(k),'predicted':np.average(g[name].to_numpy()[ix],weights=w[ix]),'observed':np.average(y[ix],weights=w[ix]),'queries':int(ix.sum())})
 pd.DataFrame(rows).to_csv(out/'paired_bootstrap.csv',index=False);pd.DataFrame(fits).to_csv(out/'calibration_diagnostics.csv',index=False);pd.DataFrame(calpoints).to_csv(out/'calibration_bins.csv',index=False)
 plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
 cp=pd.DataFrame(calpoints);fig,axes=plt.subplots(1,2,figsize=(9,4.4))
 for ax,site,title in zip(axes,['xuhui_oof','fengxian'],['Site A: outer OOF','Site B: exploratory']):
  for name,color,style in [('RF_current','#52616B','--'),('RF_current_cal','#52616B','-'),('OAF','#167F82','--'),('OAF_cal','#167F82','-')]:
   z=cp[(cp.cohort==site)&(cp.model==name)];ax.plot(z.predicted,z.observed,style,color=color,marker='o',ms=4,label=name.replace('_',' '))
  ax.plot([0,1],[0,1],':',color='#AAA');ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_xlabel('Predicted intervention probability');ax.set_ylabel('Observed intervention proportion');ax.set_title(title);ax.legend(fontsize=8);ax.grid(alpha=.15)
 fig.tight_layout();fig.savefig(out/'calibration.png',dpi=300);fig.savefig(out/'calibration.pdf');plt.close(fig)
 results=pd.DataFrame(rows);sel=results[(results.metric=='Brier')&results.contrast.isin([n+'_cal - '+n for n in NAMES])]
 fig,axes=plt.subplots(1,2,figsize=(10,4.2))
 for ax,site,title in zip(axes,['xuhui_oof','fengxian'],['Site A: outer OOF','Site B: exploratory']):
  z=sel[sel.cohort==site].set_index('contrast').loc[[n+'_cal - '+n for n in NAMES]]
  x=z.difference.to_numpy();ax.errorbar(x,range(6),xerr=np.maximum(0,np.vstack([x-z.ci_low,z.ci_high-x])),fmt='o',color='#167F82',capsize=3);ax.axvline(0,color='#999',ls='--');ax.set_yticks(range(6));ax.set_yticklabels(NAMES);ax.invert_yaxis();ax.set_xlabel('Calibrated minus raw Brier (lower is better)');ax.set_title(title);ax.xaxis.set_major_locator(MaxNLocator(5))
 fig.tight_layout();fig.savefig(out/'calibration_brier_effect.png',dpi=300);fig.savefig(out/'calibration_brier_effect.pdf');plt.close(fig)
 (out/'evaluation_complete.json').write_text(json.dumps({'outer_folds_verified':len(records),'bootstrap':boot,'patient_equal':True,'query_count':len(d),'patient_count':int(d.patient_id.nunique()),'evaluation_condition':'fitted prediction sets; no training uncertainty resampling','calibration_status':'independent source holdout; not fitted in target'},indent=2))
 print(pd.read_csv(out/'metrics.csv').round(4).to_string(index=False));print(results[results.metric.eq('AUPRC')].round(4).to_string(index=False))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--bootstrap',type=int,default=5000);a=ap.parse_args();main(a.root,a.bootstrap)
