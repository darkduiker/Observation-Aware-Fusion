from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'evaluation'
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
d=pd.read_csv(out/'paired_ensemble_bootstrap.csv')
fig,axes=plt.subplots(2,3,figsize=(12,7))
refs=['RF_current','Fixed_half','Global_weight','Global_AP','Unshrunk_gate'];names=['Current RF','Fixed 50:50','Global log-loss','Global AP-selected','Unshrunk gate']
for row,site in enumerate(['xuhui_oof','fengxian']):
 for col,metric in enumerate(['AUROC','AUPRC','Brier']):
  ax=axes[row,col];suffix='_cal' if metric=='Brier' else ''
  for candidate,offset,color,label in [('OAF',-.12,'#486C91','Brier-selected OAF'),('OAF_AP',.12,'#117F80','AP-selected OAF')]:
   z=d[(d.cohort==site)&(d.candidate==candidate+suffix)&(d.metric==metric)].set_index('reference').loc[[r+suffix for r in refs]]
   x=z.difference.to_numpy();ax.errorbar(x,np.arange(5)+offset,xerr=np.maximum(0,np.vstack([x-z.ci_low,z.ci_high-x])),fmt='o',markersize=4,capsize=2,color=color,label=label)
  ax.axvline(0,color='#9FA6AD',ls='--',lw=1);ax.set_yticks(np.arange(5),names);ax.invert_yaxis();ax.grid(axis='x',alpha=.13)
  ax.set_title(('Site A OOF' if row==0 else 'Site B exploratory')+' / '+('calibrated ' if metric=='Brier' else '')+metric)
  ax.set_xlabel('OAF minus comparator'+(' (lower is better)' if metric=='Brier' else ''))
  ax.xaxis.set_major_locator(MaxNLocator(4))
handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=2,frameon=False)
fig.tight_layout(rect=[0,0,1,.95])
for ext in ['png','pdf','svg']:fig.savefig(out/f'paired_effects.{ext}',dpi=300)
plt.close(fig)
m=pd.read_csv(out/'metrics_by_seed_and_ensemble.csv');fig,axes=plt.subplots(1,2,figsize=(9,4))
for ax,site,title in zip(axes,['xuhui_oof','fengxian'],['Site A OOF','Site B exploratory']):
 for model,color in [('RF_current','#777'),('OAF','#486C91'),('OAF_AP','#117F80'),('Fixed_half','#BA8658'),('Global_AP','#765A91')]:
  z=m[(m.cohort==site)&(m.model==model)&(m.seed.astype(str)!='ensemble')].sort_values('seed')
  ax.plot(range(3),z.AUPRC,'o-',color=color,label=model,ms=4)
 ax.set_xticks(range(3),['2026','2027','2028']);ax.set_xlabel('Fitting seed on the fixed patient roster');ax.set_ylabel('Patient-equal AUPRC');ax.set_title(title);ax.grid(axis='y',alpha=.15)
axes[1].legend(fontsize=7);fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(out/f'seed_auprc.{ext}',dpi=300)
plt.close(fig)
