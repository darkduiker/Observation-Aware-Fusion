"""Read the labor workbook without modifying the source file."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any

import numpy as np
import pandas as pd

from .labor_schema import (
    BASELINE_COLUMNS,
    EVENT_SPECS,
    FETAL_POSITION_VOCAB,
    OUTCOME_COLUMN,
    PATIENT_ID_COLUMN,
    PLACEHOLDERS,
    UNTIMESTAMPED_DYNAMIC_COLUMNS,
    site_from_patient_id,
    stage_from_dilation,
)


@dataclass
class LaborDataBundle:
    patients: pd.DataFrame
    events: pd.DataFrame
    landmarks: pd.DataFrame
    quality: pd.DataFrame
    source_rows: int

    def summary(self) -> dict[str, Any]:
        eligible = self.patients[self.patients["eligible"]]
        return {
            "source_rows": int(self.source_rows),
            "patients": int(len(self.patients)),
            "eligible_patients": int(len(eligible)),
            "events": int(len(self.events)),
            "valid_timed_events": int(self.events["event_time"].notna().sum()),
            "landmarks": int(len(self.landmarks)),
            "site_counts": eligible["site"].value_counts().sort_index().to_dict(),
            "outcome_counts": eligible["outcome_3class"].value_counts().sort_index().to_dict(),
            "stage_counts": self.landmarks["stage"].value_counts().sort_index().to_dict(),
            "quality_flags": self.quality["issue"].value_counts().sort_index().to_dict(),
        }


def _clean_header(value: Any) -> str:
    return str(value).replace("\n", "").strip()


def _clean_decimal(value: Any) -> float:
    if pd.isna(value):
        return np.nan
    if isinstance(value, str):
        text = value.strip().lower().replace("，", ".").replace(",", ".")
        if text in PLACEHOLDERS:
            return np.nan
        match = re.fullmatch(r"[-+]?\d+(?:\.\d+)?", text)
        if match is None:
            return np.nan
        return float(text)
    try:
        return float(value)
    except (TypeError, ValueError):
        return np.nan


def parse_excel_timestamp(value: Any) -> tuple[pd.Timestamp | pd.NaT, str]:
    """Parse mixed Excel timestamps and return a transparent quality label."""
    if pd.isna(value):
        return pd.NaT, "missing"

    if isinstance(value, pd.Timestamp):
        parsed = value
        source = "native_timestamp"
    elif isinstance(value, (int, float, np.integer, np.floating)):
        parsed = pd.Timestamp("1899-12-30") + pd.to_timedelta(float(value), unit="D")
        source = "excel_serial"
    else:
        text = str(value).strip()
        text = (
            text.replace("：", ":")
            .replace("／", "/")
            .replace("—", "-")
            .replace("–", "-")
            .lstrip(":")
            .replace("\n", " ")
        )
        text = re.sub(r"\s+", " ", text)
        if re.fullmatch(r"\d{5}(?:\.\d+)?", text):
            parsed = pd.Timestamp("1899-12-30") + pd.to_timedelta(float(text), unit="D")
            source = "excel_serial_text"
        else:
            parsed = pd.to_datetime(text, errors="coerce")
            source = "parsed_text"

    if pd.isna(parsed):
        return pd.NaT, "invalid"
    if getattr(parsed, "tzinfo", None) is not None:
        parsed = parsed.tz_localize(None)
    return pd.Timestamp(parsed), source


class LaborWorkbookLoader:
    """Convert the single-sheet workbook into patient, event, and landmark tables."""

    def __init__(self, workbook: str | Path, sheet_name: str = "Sheet1") -> None:
        self.workbook = Path(workbook)
        self.sheet_name = sheet_name

    def _read_source(self) -> pd.DataFrame:
        if not self.workbook.exists():
            raise FileNotFoundError(self.workbook)
        frame = pd.read_excel(self.workbook, sheet_name=self.sheet_name, header=1)
        frame.columns = [_clean_header(column) for column in frame.columns]
        if PATIENT_ID_COLUMN not in frame or OUTCOME_COLUMN not in frame:
            raise ValueError("Workbook header row was not detected at Excel row 2")
        # The first row beneath the header contains clinical reference values.
        frame = frame.loc[frame[PATIENT_ID_COLUMN].astype(str).str.strip() != "参考值"].reset_index(drop=True)
        return frame

    @staticmethod
    def _assign_patient_rows(frame: pd.DataFrame) -> pd.DataFrame:
        assigned = frame.copy()
        start_ids = pd.to_numeric(assigned[PATIENT_ID_COLUMN], errors="coerce")
        assigned["patient_id"] = start_ids.ffill()
        assigned = assigned.loc[assigned["patient_id"].notna()].copy()
        assigned["patient_id"] = assigned["patient_id"].astype(int)
        assigned["patient_start_row"] = start_ids.loc[assigned.index].notna().to_numpy()
        assigned["source_row"] = assigned.index + 4
        return assigned.reset_index(drop=True)

    def _build_patients(self, rows: pd.DataFrame) -> pd.DataFrame:
        records: list[dict[str, Any]] = []
        for patient_id, group in rows.groupby("patient_id", sort=True):
            start = group.loc[group["patient_start_row"]]
            if start.empty:
                start = group.iloc[[0]]
            first = start.iloc[0]
            outcome = _clean_decimal(first.get(OUTCOME_COLUMN))
            record: dict[str, Any] = {
                "patient_id": int(patient_id),
                "site": site_from_patient_id(int(patient_id)),
                "outcome_3class": int(outcome) if np.isfinite(outcome) else pd.NA,
                "outcome_binary": int(outcome != 1.0) if np.isfinite(outcome) else pd.NA,
                "source_row_count": int(len(group)),
            }
            for column in BASELINE_COLUMNS:
                record[column] = first.get(column, np.nan)
            for column in UNTIMESTAMPED_DYNAMIC_COLUMNS:
                record[f"audit_only__{column}"] = first.get(column, np.nan)
            records.append(record)
        patients = pd.DataFrame.from_records(records)
        patients["eligible"] = False
        return patients

    def _build_events(self, rows: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
        events: list[dict[str, Any]] = []
        quality: list[dict[str, Any]] = []

        for spec in EVENT_SPECS:
            if spec.value_column not in rows or spec.time_column not in rows:
                quality.append({
                    "patient_id": pd.NA,
                    "source_row": pd.NA,
                    "variable": spec.name,
                    "issue": "missing_source_column",
                    "detail": f"{spec.value_column} | {spec.time_column}",
                })
                continue

            for row_dict in rows.to_dict(orient="records"):
                raw_value = row_dict.get(spec.value_column)
                raw_time = row_dict.get(spec.time_column)
                if pd.isna(raw_value) and pd.isna(raw_time):
                    continue

                event_time, time_quality = parse_excel_timestamp(raw_time)
                if spec.value_kind == "categorical":
                    text_value = None if pd.isna(raw_value) else str(raw_value).strip()
                    numeric_value = FETAL_POSITION_VOCAB.get(text_value, 0) if text_value else np.nan
                else:
                    text_value = None
                    numeric_value = _clean_decimal(raw_value)

                value_valid = bool(np.isfinite(numeric_value))
                enabled = bool(spec.enabled and value_valid and pd.notna(event_time))
                events.append({
                    "patient_id": int(row_dict["patient_id"]),
                    "source_row": int(row_dict["source_row"]),
                    "variable": spec.name,
                    "modality": spec.modality,
                    "value": numeric_value,
                    "category_text": text_value,
                    "event_time": event_time,
                    "time_quality": time_quality,
                    "value_valid": value_valid,
                    "enabled": enabled,
                    "raw_value": raw_value,
                    "raw_time": raw_time,
                })

                if not value_valid:
                    quality.append({
                        "patient_id": int(row_dict["patient_id"]),
                        "source_row": int(row_dict["source_row"]),
                        "variable": spec.name,
                        "issue": "invalid_or_placeholder_value",
                        "detail": str(raw_value),
                    })
                if time_quality == "invalid":
                    quality.append({
                        "patient_id": int(row_dict["patient_id"]),
                        "source_row": int(row_dict["source_row"]),
                        "variable": spec.name,
                        "issue": "invalid_timestamp",
                        "detail": str(raw_time),
                    })
                if value_valid and pd.isna(event_time):
                    quality.append({
                        "patient_id": int(row_dict["patient_id"]),
                        "source_row": int(row_dict["source_row"]),
                        "variable": spec.name,
                        "issue": "value_without_valid_time",
                        "detail": str(raw_time),
                    })

        event_frame = pd.DataFrame.from_records(events)
        if event_frame.empty:
            event_frame = pd.DataFrame(columns=[
                "patient_id", "source_row", "variable", "modality", "value",
                "category_text", "event_time", "time_quality", "value_valid",
                "enabled", "raw_value", "raw_time",
            ])
        else:
            event_frame = event_frame.sort_values(
                ["patient_id", "event_time", "source_row", "variable"],
                na_position="last",
            ).reset_index(drop=True)
        return event_frame, pd.DataFrame.from_records(quality)

    @staticmethod
    def _add_temporal_quality(events: pd.DataFrame, quality: pd.DataFrame) -> pd.DataFrame:
        dilation = events[
            (events["variable"] == "cervical_dilation")
            & events["value_valid"]
            & events["event_time"].notna()
        ].sort_values(["patient_id", "source_row"])
        if not dilation.empty:
            deltas = dilation.groupby("patient_id")["event_time"].diff().dt.total_seconds()
            bad = dilation.loc[deltas < 0]
            additions = [
                {
                    "patient_id": int(row.patient_id),
                    "source_row": int(row.source_row),
                    "variable": "cervical_dilation",
                    "issue": "negative_interval_in_source_order",
                    "detail": "timestamp precedes the previous source-row timestamp",
                }
                for row in bad.itertuples(index=False)
            ]
            if additions:
                quality = pd.concat([quality, pd.DataFrame(additions)], ignore_index=True)
        return quality

    @staticmethod
    def _build_landmarks(events: pd.DataFrame, patients: pd.DataFrame) -> pd.DataFrame:
        dilation = events[
            (events["variable"] == "cervical_dilation")
            & events["enabled"]
        ].copy()
        dilation["stage"] = dilation["value"].map(stage_from_dilation)
        dilation = dilation.loc[dilation["stage"].notna()]
        dilation = dilation.sort_values(["patient_id", "event_time", "source_row"])
        landmarks = dilation.groupby(["patient_id", "stage"], as_index=False).first()
        if landmarks.empty:
            return pd.DataFrame(columns=[
                "patient_id", "site", "stage", "query_time", "dilation_value",
                "outcome_3class", "outcome_binary", "landmark_source_row",
            ])
        landmarks = landmarks.rename(columns={
            "event_time": "query_time",
            "value": "dilation_value",
            "source_row": "landmark_source_row",
        })
        landmark_columns = [
            "patient_id", "stage", "query_time", "dilation_value", "landmark_source_row"
        ]
        landmarks = landmarks[landmark_columns].merge(
            patients[["patient_id", "site", "outcome_3class", "outcome_binary"]],
            on="patient_id",
            how="left",
            validate="many_to_one",
        )
        stage_order = pd.CategoricalDtype(["lt4", "4to6", "6to10"], ordered=True)
        landmarks["stage"] = landmarks["stage"].astype(stage_order)
        return landmarks.sort_values(["patient_id", "stage"]).reset_index(drop=True)

    def load(self) -> LaborDataBundle:
        source = self._read_source()
        rows = self._assign_patient_rows(source)
        patients = self._build_patients(rows)
        events, quality = self._build_events(rows)
        quality = self._add_temporal_quality(events, quality)
        eligible_ids = set(
            events.loc[
                (events["variable"] == "cervical_dilation") & events["value_valid"],
                "patient_id",
            ].astype(int)
        )
        patients["eligible"] = patients["patient_id"].isin(eligible_ids)
        landmarks = self._build_landmarks(events, patients)
        quality = quality.sort_values(
            ["patient_id", "source_row", "variable"], na_position="last"
        ).reset_index(drop=True) if not quality.empty else quality
        return LaborDataBundle(
            patients=patients,
            events=events,
            landmarks=landmarks,
            quality=quality,
            source_rows=int(len(rows)),
        )
