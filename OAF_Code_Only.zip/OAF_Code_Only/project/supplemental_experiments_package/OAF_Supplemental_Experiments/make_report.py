from pathlib import Path
import pandas as pd,numpy as np,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
root=Path(__file__).resolve().parent
s=pd.read_csv(root/'simulation_summary.csv');c=pd.read_csv(root/'simulation_paired_effects.csv');r=pd.read_csv(root/'real_stress_summary.csv');e=pd.read_csv(root/'real_stress_paired_effects.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
models=['Current_RF','History_RF','Fixed_half','Global_weight','Unshrunk_gate','OAF'];colors=['#52616B','#B4564A','#92A9BC','#7E759B','#C69859','#167F82']
fig,axes=plt.subplots(1,3,figsize=(12,4.3),sharey=True)
for ax,scenario,title in zip(axes,['stable_informative','policy_shift_informative','redundant_history'],['Stable observation, useful history','Changed observation, useful history','Changed observation, redundant history']):
 d=s[(s.scenario==scenario)&(s.site=='shifted_test')&(s.metric=='AUPRC')].set_index('model').loc[models]
 ax.bar(range(6),d['mean'],color=colors,width=.7,yerr=np.vstack([d['mean']-d.mean_ci_low,d.mean_ci_high-d['mean']]),capsize=3,error_kw={'lw':1})
 ax.set_xticks(range(6));ax.set_xticklabels(['Current RF','History RF','50:50 blend','Global blend','Unshrunk gate','OAF'],rotation=45,ha='right');ax.set_title(title,fontsize=10);ax.set_ylim(0,.8);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
axes[0].set_ylabel('Average precision');fig.text(.5,.015,'Synthetic RF-expert diagnostic: 24 repetitions; bars show means, intervals show Monte Carlo uncertainty of the mean.',ha='center',fontsize=8);fig.tight_layout(rect=[0,.05,1,1]);fig.savefig(root/'simulation_performance.png',dpi=300);fig.savefig(root/'simulation_performance.pdf');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(10,4.4))
for ax,site,title in zip(axes,['xuhui_oof','fengxian'],['Site A (development OOF)','Site B (exploratory)']):
 d=e[(e.site==site)&(e.dropout==.4)&(e.metric=='AUPRC')].set_index('contrast').loc[['OAF - RF_current','OAF - D','OAF - Fixed_half','OAF - Global_weight','OAF - OAF_same6_no_shrink']]
 x=d['mean'].to_numpy();ax.errorbar(x,np.arange(5),xerr=np.maximum(0,np.vstack([x-d.ci_low,d.ci_high-x])),fmt='o',color='#167F82',capsize=3);ax.axvline(0,color='#79858C',lw=1,ls='--');ax.set_yticks(range(5));ax.set_yticklabels(['vs current RF','vs combined-history RF','vs 50:50 blend','vs global blend','vs unshrunk gate']);ax.invert_yaxis();ax.set_xlabel('OAF difference in average precision');ax.set_title(title);ax.grid(axis='x',alpha=.15);ax.xaxis.set_major_locator(MaxNLocator(5))
fig.suptitle('40% older-history deletion: paired performance effects',fontsize=12);fig.text(.5,.012,'95% intervals resample patients and shared deletion masks; conditional on the archived fitted predictions.',ha='center',fontsize=8);fig.tight_layout(rect=[0,.05,1,.94]);fig.savefig(root/'clinical_stress_effects.png',dpi=300);fig.savefig(root/'clinical_stress_effects.pdf');plt.close(fig)

def table(d):
 cols=list(d.columns);return '| '+' | '.join(cols)+' |\n| '+' | '.join(['---']*len(cols))+' |\n'+'\n'.join('| '+' | '.join(str(v) for v in row)+' |' for row in d.itertuples(index=False,name=None))
x=s[(s.site=='shifted_test')&(s.metric=='AUPRC')].pivot(index='model',columns='scenario',values='mean').reindex(models).round(4).reset_index()
y=r[(r.dropout==.4)&(r.metric=='AUPRC')].pivot(index='model',columns='site',values='mean').round(4).reset_index()
z=e[(e.dropout==.4)&(e.metric=='AUPRC')].copy();z['effect [95% interval]']=z.apply(lambda a:f"{a['mean']:+.4f} [{a.ci_low:+.4f}, {a.ci_high:+.4f}]",axis=1)
z=z[['site','contrast','effect [95% interval]']]
report='''# OAF 补充实验：是否有增益？

## 结论

**有条件的增益，但现有 OAF 仍不能普遍解决观察机制变化，也没有证明必须使用观察门控。** 不建议据此声称一区级方法创新已成立。

本轮新增的是：72 组可控模拟实验（3 场景 × 24 次重复），以及真实患者旧历史删除结果的患者与掩码双重重采样。没有重新训练临床 RF/GRU-D，没有更改现有论文的任何原始数字。

## 一、可控模拟

每次使用 640 名合成训练患者、240 名独立源域门控训练患者及每域 1,000 名独立测试患者。训练与门控选择完全不使用目标域结局。门控沿用原代码的标准化、正则化和收缩强度网格，以源域三折 Brier 选择强度。为控制运行成本，模拟的历史专家是 RF，而非临床模型的 GRU-D；这是门控机制的结构诊断，不能直接当作临床 OAF 效果复现。

真实结局由当前状态与潜在生理变化生成。重新评估机会由临床严重程度决定；“策略变化”场景反转严重程度与重复测量概率的关系，而不改变结局生成机制。“历史冗余”场景从结局生成式中删除历史贡献。所有方法共用相同的当前与历史专家、训练集及评价患者。这里使用一名合成患者一个查询，未模拟真实多查询相关结构。

目标域平均精确率（AP，论文中称 AUPRC）：

'''+table(x)+'''

解释：稳定场景下，OAF 利用了有用历史，超过 current RF；但没有超过全局融合。在强策略变化下，OAF 优于纯 history RF，却明显低于 current RF 和固定 50:50 融合。历史冗余时，OAF 也没有稳定优于 current RF。

因此，本次模拟发现的是**有益历史与不稳定观察信号之间的取舍**，不是普遍的恢复或稳健性保证。不能只截取稳定场景的正结果进入论文。

另测试了独立源域门控训练集上的逻辑校准。正斜率的单调校准未改变 AP，Brier 是否改善随场景而变；它无法修复排序层面的观察策略失稳。校准在源域独立门控集拟合，但并非又新增一层独立门控选择集。

各差值、重复间标准差及均值区间见 simulation_paired_effects.csv / simulation_summary.csv。模拟区间表示该指定生成机制下的 Monte Carlo 均值不确定性，不是临床患者置信区间，也不能推广到所有观察机制。

## 二、真实数据：40% 旧历史删除

共 854 名患者 / 1,596 个 phase-first 查询；徐汇 736/1,378，奉贤 118/218。保持当前状态，不重新训练专家。对已保存的 10 组配对删除掩码，重采样患者与掩码各 2,000 次；每个患者在指标中等权。先计算每个掩码的指标，再取掩码均值，不对预测先求平均来替代扰动评价。

各方法的平均 AP：

'''+table(y)+'''

OAF 的配对 AP 差值：

'''+table(z)+'''

缩小概率响应并不等于提高预测质量：奉贤中，固定融合及无收缩门控的扰动后 AP 点估计仍高于 OAF。对照必须一并呈现。完整 Brier、AUROC 和概率响应见 real_stress_summary.csv；对应配对差值见 real_stress_paired_effects.csv。

**奉贤在该 40% 删除场景中，OAF 相对 current RF 的 AP 增量为 +0.0276（95% 区间 +0.0022 至 +0.0582）；相对 combined-history RF 为 +0.0625（+0.0219 至 +0.1056）。** 这是扰动场景中的条件性增益，不是未扰动主实验的新增收益，不能替换原主结果。多个场景和对照尚未做多重比较校正，区间应按探索性结果解释。

这些区间同时纳入患者与 10 组已保存掩码的经验重采样变异，但仍条件于现有拟合模型，并不能涵盖重训练的不确定性或尚未生成的其他扰动模式。

## 三、对论文的判断与下一步

1. 现有证据支持：OAF 在部分情形下缓解直接接入历史分支的损害；不支持普遍胜过 current RF 或简单融合。
2. 当前门控在开发分布中选择，无法保证识别目标域中历史预测关系的反转。单纯继续调收缩参数不能解决这个不可识别性问题。
3. 若继续做方法升级，应明确补充假设或信息，例如训练内构造多种观察策略变化，以联合评价稳定信息收益与最坏情形损害；这将是新的候选方法，需要重新嵌套开发，不能根据奉贤结果选版本。
4. 不自动把本次合成反例全部塞进主稿；先决定是否将它作为模拟章节与方法边界，再同步调整结论。原稿与原结果包保持不变。

## 运行与文件

双击或运行 START.py；命令行支持 --replicates、--bootstrap、--only。完整重跑约数分钟至十余分钟，取决于计算机。需要 numpy、pandas、scipy、scikit-learn、matplotlib。真实数据重采样读取包内保存的患者级预测，不需要 torch；不包含原始患者测量表。

本轮协议、代码、逐次结果、调参记录和图片全部保留。种子与生成式见 protocol.json 和 run_experiments.py。目标域标签仅用于最终指标计算。
'''
(root/'EXPERIMENT_FINDINGS.md').write_text(report)
print(z.to_string(index=False))
