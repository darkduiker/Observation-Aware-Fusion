"""One Python entry point. Edit MODE only to change the operation."""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parent
MODE="verify"  # verify / train_nested / train_primary
def main(mode=MODE):
    if mode=="verify":
        subprocess.run([sys.executable,str(ROOT/"VERIFY_RESULTS.py")],check=True,cwd=ROOT)
    elif mode=="train_nested":
        if sys.version_info<(3,12):raise RuntimeError("Full retraining requires Python 3.12; see README.txt.")
        subprocess.run([sys.executable,"-m","pip","install","-r",str(ROOT/"nested_validation/requirements.txt")],check=True)
        # Keep archived result predictions and train into a separate new directory.
        fresh=ROOT/"nested_retraining"
        fresh.mkdir(exist_ok=True)
        import shutil
        for name in ["code","processed"]:
            if not (fresh/name).exists():shutil.copytree(ROOT/"nested_validation"/name,fresh/name)
        for name in ["TRAIN_START.py","requirements.txt"]:shutil.copy2(ROOT/"nested_validation"/name,fresh/name)
        subprocess.run([sys.executable,str(fresh/"TRAIN_START.py")],check=True,cwd=fresh)
    elif mode=="train_primary":
        subprocess.run([sys.executable,str(ROOT/"primary_benchmark/START.py"),"--processed",str(ROOT/"primary_benchmark/processed_private")],check=True,cwd=ROOT/"primary_benchmark")
    else:raise ValueError("Unknown MODE")

if __name__=="__main__":
    main()
