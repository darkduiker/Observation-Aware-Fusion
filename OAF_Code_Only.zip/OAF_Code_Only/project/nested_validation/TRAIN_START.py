"""Resume all three fully nested seeds, evaluate, and run history-deletion tests."""
from pathlib import Path
import subprocess,sys,os
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
 env=os.environ.copy();env.setdefault('OPENBLAS_NUM_THREADS','1');env.setdefault('OMP_NUM_THREADS','2')
 for seed in [2026,2027,2028]:
  subprocess.run([sys.executable,str(ROOT/'code/run_fully_nested.py'),'--processed',str(ROOT/'processed'),'--output',str(ROOT/f'results_{seed}'),'--seeds',str(seed),'--threads','2','--jobs','2'],env=env,check=True)
 subprocess.run([sys.executable,str(ROOT/'code/evaluate_multiseed.py'),'--root',str(ROOT)],env=env,check=True)
 for seed in [2026,2027,2028]:
  subprocess.run([sys.executable,str(ROOT/'code/run_stress.py'),'--root',str(ROOT),'--seed',str(seed)],env=env,check=True)
 subprocess.run([sys.executable,str(ROOT/'code/evaluate_stress.py'),'--root',str(ROOT)],env=env,check=True)
 subprocess.run([sys.executable,str(ROOT/'code/draw_results.py')],env=env,check=True)
