from pathlib import Path
import sys,subprocess,os
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
 for script in ['evaluate_multiseed.py','evaluate_stress.py','draw_results.py']:
  subprocess.run([sys.executable,str(ROOT/'code'/script)],check=True)
