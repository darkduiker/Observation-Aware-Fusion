from pathlib import Path
import argparse,pickle,json,time
import numpy as np,pandas as pd,torch
from run_nested import load_data,build_samples,observations,thin_samples,tensors,predict_tensor,model_for,metadata
from run_fully_nested import NAMES
from opal_fusion.baselines.tabular import tabularize_samples
from fusion import Fusion
from scipy.special import expit,logit

def main(root,seed,masks=10):
 torch.set_num_threads(1);r=root/f'results_{seed}';p,e,q,f=load_data(root/'processed');pieces=[]
 for fold in range(5):
  dest=r/f'seed_{seed}/fold_{fold}';out=dest/'stress.csv'
  if out.exists():pieces.append(pd.read_csv(out));continue
  while not (dest/'complete.json').exists():
   print('Waiting for trained fold',seed,fold,flush=True);time.sleep(5)
  audit=json.loads((dest/'complete.json').read_text());cache=r/'expert_cache'/audit['final_expert_cache'];saved=pickle.load(open(cache/'rf_prep.pkl','rb'));prep=saved['prep'];rf=saved['rf']
  net=model_for(prep,128);net.load_state_dict(torch.load(cache/'grud.pt',map_location='cpu',weights_only=True));net.eval();gates=pickle.load(open(dest/'gates.pkl','rb'));rows=[]
  for cohort,ids in [('xuhui_oof',audit['outer_validation_ids']),('fengxian',audit['target_ids'])]:
   ss=build_samples(p,e,q,ids,prep);m=metadata(ss);original=tabularize_samples(ss,prep.n_variables,'current').features;c=rf.predict_proba(original)[:,1]
   for b in range(masks):
    changed=[thin_samples([s],.4,20261003+int(s['patient_id'])*100+int(s['stage_id'])*10+b)[0] for s in ss]
    now=tabularize_samples(changed,prep.n_variables,'current').features;assert np.array_equal(now,original)
    h=predict_tensor(net,tensors(changed));obs,reliability=observations(changed);d=m.copy();d['RF_current']=c;d['GRUD']=h
    for name,g in gates.items():d[name]=g.predict(c,h,obs,reliability)
    for name in NAMES:
     a=audit['calibration_params'][name];d[name+'_cal']=expit(a['intercept']+a['slope']*logit(np.clip(d[name],1e-6,1-1e-6)))
    d['cohort']=cohort;d['seed']=seed;d['fold']=fold;d['mask']=b;d['dropout']=.4;rows.append(d)
  frame=pd.concat(rows,ignore_index=True);frame.to_csv(out,index=False);pieces.append(frame);print('STRESS',seed,fold,flush=True)
 full=pd.concat(pieces,ignore_index=True);full.to_csv(r/'stress_fold_predictions.csv',index=False)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--seed',type=int,required=True);a=ap.parse_args();main(a.root,a.seed)
