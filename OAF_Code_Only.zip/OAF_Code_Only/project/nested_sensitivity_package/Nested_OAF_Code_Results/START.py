"""Run the complete nested verification, then evaluation."""
from pathlib import Path
import sys,subprocess,argparse
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,nargs='+',default=[2026]);ap.add_argument('--bootstrap',type=int,default=5000);a=ap.parse_args()
subprocess.run([sys.executable,str(root/'code/run_fully_nested.py'),'--seeds',*map(str,a.seeds)],cwd=root,check=True)
subprocess.run([sys.executable,str(root/'code/verify_epoch_splits.py')],cwd=root,check=True)
subprocess.run([sys.executable,str(root/'code/evaluate_nested.py'),'--bootstrap',str(a.bootstrap)],cwd=root,check=True)
subprocess.run([sys.executable,str(root/'code/write_findings.py')],cwd=root,check=True)
print('Complete: results/ and FINDINGS.md. Keep all clinical data private.')
