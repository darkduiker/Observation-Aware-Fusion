from pathlib import Path
import json,argparse
import numpy as np,pandas as pd
from fast_metric import Prepared
from fusion import patient_weights
from run_fully_nested import NAMES

def main(root,boot=2000):
 out=root/'evaluation';baseline=pd.read_csv(out/'ensemble_predictions.csv');pieces=[];cols=NAMES+[n+'_cal' for n in NAMES]
 for seed in [2026,2027,2028]:
  d=pd.read_csv(root/f'results_{seed}/stress_fold_predictions.csv')
  keys=['patient_id','stage_id','target','cohort','mask']
  z=pd.concat([d[d.cohort.eq('xuhui_oof')][keys+cols],d[d.cohort.eq('fengxian')].groupby(keys,as_index=False)[cols].mean()],ignore_index=True)
  assert len(z)==15960;z['seed']=seed;pieces.append(z)
 ens=pd.concat(pieces).groupby(keys,as_index=False)[cols].mean();ens.to_csv(out/'stress_ensemble_predictions.csv',index=False)
 rows=[];pairs=[];rng=np.random.default_rng(20261005)
 for site in ['xuhui_oof','fengxian']:
  base=baseline[baseline.cohort.eq(site)].sort_values(['patient_id','stage_id']).reset_index(drop=True);ids,inv,cnt=np.unique(base.patient_id,return_inverse=True,return_counts=True);w=1/cnt[inv];y=base.target.to_numpy()
  cache={n:[] for n in cols}
  for b in range(10):
   z=ens[(ens.cohort==site)&(ens['mask']==b)].sort_values(['patient_id','stage_id']).reset_index(drop=True)
   assert np.array_equal(z.patient_id,base.patient_id) and np.array_equal(z.stage_id,base.stage_id)
   assert np.max(abs(z.RF_current-base.RF_current))<1e-12
   for n in cols:cache[n].append(Prepared(y,z[n].to_numpy(),base[n].to_numpy()))
  points={n:np.mean([m.values(w) for m in cache[n]],axis=0) for n in cols};draws={n:np.empty((boot,4)) for n in cols}
  for b in range(boot):
   ww=w*rng.multinomial(len(ids),np.ones(len(ids))/len(ids))[inv];mw=rng.multinomial(10,np.ones(10)/10)/10
   for n in cols:draws[n][b]=sum(mw[k]*cache[n][k].values(ww) for k in range(10) if mw[k]>0)
  for n in cols:
   v=points[n];rows.append({'cohort':site,'model':n,'AUPRC':v[0],'AUROC':v[1],'Brier':v[2],'mean_absolute_response':v[3]})
  for candidate in ['OAF','OAF_AP','OAF_cal','OAF_AP_cal']:
   suffix='_cal' if candidate.endswith('_cal') else ''
   for n in ['RF_current','Fixed_half','Global_weight','Unshrunk_gate','Global_AP']:
    reference=n+suffix;pt=points[candidate]-points[reference];di=draws[candidate]-draws[reference]
    for j,m in enumerate(['AUPRC','AUROC','Brier','response']):
     lo,hi=np.quantile(di[:,j],[.025,.975]);pairs.append({'cohort':site,'candidate':candidate,'reference':reference,'metric':m,'difference':pt[j],'ci_low':lo,'ci_high':hi,'bootstrap':boot})
 pd.DataFrame(rows).to_csv(out/'stress_metrics.csv',index=False);pd.DataFrame(pairs).to_csv(out/'stress_paired_joint_bootstrap.csv',index=False)
 (out/'STRESS_COMPLETE.json').write_text(json.dumps({'rate':.4,'masks':10,'bootstrap':boot,'preserved_current_assertion':True,'uncertainty':'joint patients and empirical mask resampling; conditional on fitted experts','shared_masks':'deterministic patient/landmark/mask IDs; identical across models/folds/seeds'},indent=2))
 print(pd.DataFrame(rows).round(5).to_string(index=False))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=ap.parse_args();main(a.root)
