"""Exploratory gate redesign on saved fully nested expert cross-fits.
Target outcomes never enter model fitting or candidate selection.
Experts are held fixed; this is NOT independent prospective validation.
"""
from pathlib import Path
import sys,json
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.special import expit,logit
from sklearn.metrics import average_precision_score,roc_auc_score
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'package/OAF_v39/nested_validation'
sys.path.insert(0,str(BASE/'code'))
def patient_weights(ids):
 _,inv,counts=np.unique(ids,return_inverse=True,return_counts=True)
 return 1./counts[inv]
def raw_observations():
 e=pd.read_csv(BASE/'processed/events.csv');q=pd.read_csv(BASE/'processed/landmarks.csv')
 e=e[e.enabled.astype(str).str.lower().eq('true')].copy();e['event_time']=pd.to_datetime(e.event_time,format='mixed',errors='coerce');q['query_time']=pd.to_datetime(q.query_time,format='mixed')
 names=['pelvic_inlet_ap','pubic_arch_angle','fetal_position','midline_angle','spine_occiput_angle','chin_chest_angle','cervical_length','cervical_effacement','aop','head_station','progression_distance','head_direction_angle','hpd_recorded','cervical_dilation'];rows=[]
 groups=dict(tuple(e.groupby('patient_id')))
 for row in q.itertuples():
  if row.site not in ['xuhui','fengxian']:continue
  hist=groups.get(row.patient_id,e.iloc[:0]);hist=hist[hist.event_time.le(row.query_time)&hist.variable.isin(names)]
  counts=[];repeat=[];ages=[];last=[]
  for name in names:
   t=((row.query_time-hist.loc[hist.variable.eq(name),'event_time']).dt.total_seconds()/3600).to_numpy(np.float32)
   counts.append(len(t));repeat.append(len(np.unique(t))>=2);ages.extend(t)
   if len(t):last.append(float(t.min()))
  stage={'lt4':0,'4to6':1,'6to10':2}[row.stage];span=float(max(ages)-min(ages)) if ages else 0.
  obs=[stage/2,np.mean(np.asarray(counts)>0),np.log1p(len(ages))/4,np.log1p(np.median(last) if last else 0)/4,np.mean(repeat),np.log1p(span)/4]
  rows.append({'patient_id':row.patient_id,'stage_id':stage,'reliability':np.mean([repeat[names.index(n)] for n in ['aop','head_station','hpd_recorded','cervical_dilation']]),**{f'obs_{j}':obs[j] for j in range(6)}})
 return pd.DataFrame(rows)

def arrays(m):return m.current.to_numpy(),m.history.to_numpy(),m[[f'obs_{j}' for j in range(6)]].to_numpy(),m.target.to_numpy(),m.patient_id.to_numpy()
def feats(c,h,o,mode):
 score=np.column_stack([logit(np.clip(c,.001,.999)),logit(np.clip(h,.001,.999)),h-c,abs(h-c)])
 if mode=='obs':return o
 if mode=='score':return score
 return np.column_stack([o,score,(h-c)*o[:,4],abs(h-c)*o[:,5]])
class Gate:
 def __init__(self,mode,kind,reg):self.mode,self.kind,self.reg=mode,kind,reg
 def fit(self,m):
  c,h,o,y,ids=arrays(m);w=patient_weights(ids);w/=w.sum();raw=feats(c,h,o,self.mode);self.mean=raw.mean(0);self.std=np.maximum(raw.std(0),1e-4)
  x=np.column_stack([np.ones(len(m)),np.clip((raw-self.mean)/self.std,-3,3)]);d=h-c
  rng=np.random.default_rng(104);pos=np.where(y==1)[0];neg=np.where(y==0)[0]
  ip=rng.choice(pos,3000,replace=True,p=w[pos]/w[pos].sum());ineg=rng.choice(neg,3000,replace=True,p=w[neg]/w[neg].sum())
  def fun(b):
   g=expit(x@b);p=np.clip(c+g*d,1e-5,1-1e-5);dp=g*(1-g)*d
   if self.kind=='brier':
    loss=np.sum(w*(p-y)**2);grad=x.T@(2*w*(p-y)*dp)
   else:
    z=logit(p);dif=z[ip]-z[ineg];loss=np.logaddexp(0,-dif).mean()
    dz=np.zeros(len(m));s=-expit(-dif)/len(ip);np.add.at(dz,ip,s);np.add.at(dz,ineg,-s)
    grad=x.T@(dz/(p*(1-p))*dp)
   penalty=self.reg*np.dot(b[1:],b[1:])+0.01*b[0]**2
   grad[1:]+=2*self.reg*b[1:];grad[0]+=.02*b[0]
   return loss+penalty,grad
  fit=minimize(fun,np.zeros(x.shape[1]),jac=True,method='L-BFGS-B',options={'maxiter':120})
  if not np.isfinite(fit.fun):raise ValueError('nonfinite gate')
  self.b=fit.x;return self
 def predict(self,m):
  c,h,o,_,_=arrays(m);x=np.column_stack([np.ones(len(m)),np.clip((feats(c,h,o,self.mode)-self.mean)/self.std,-3,3)])
  return c+expit(x@self.b)*(h-c)
def score(m,p):
 w=patient_weights(m.patient_id.to_numpy());return float(average_precision_score(m.target,p,sample_weight=w)),float(np.average((m.target-p)**2,weights=w))
def calibrate(cal,pcal,test,p):
 w=patient_weights(cal.patient_id.to_numpy());w/=w.sum();x=logit(np.clip(pcal,1e-6,1-1e-6));y=cal.target.to_numpy()
 def fun(b):
  z=b[0]+b[1]*x;d=w*(expit(z)-y)
  return np.sum(w*(np.logaddexp(0,z)-y*z))+1e-4*np.dot(b,b),np.array([d.sum(),np.dot(d,x)])+2e-4*b
 r=minimize(fun,[0.,1.],jac=True,bounds=[(None,None),(0,None)],method='L-BFGS-B');return expit(r.x[0]+r.x[1]*logit(np.clip(p,1e-6,1-1e-6)))
def enrich(m,lookup):
 out=m.rename(columns={'RF_current':'current','GRUD':'history'}).copy()
 return out.merge(lookup,on=['patient_id','stage_id'],validate='many_to_one')
def main():
 ROOT.mkdir(exist_ok=True);protocol={'modes':['obs','score','combined'],'objectives':['brier','ranking'],'penalties':[.01,.1,1.], 'selection':'AP in pooled source meta-validation; ties favor higher penalty','seed':104,'target_used_for_selection':False,'expert_retraining':False}
 (ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2))
 lookup=raw_observations()
 cached=pd.read_csv(BASE/'results_2026/seed_2026/fold_0/core_expert_oof.csv')
 chk=cached.merge(lookup,on=['patient_id','stage_id'],suffixes=('_saved','_raw'))
 for name in ['reliability']+[f'obs_{j}' for j in range(6)]:
  assert np.allclose(chk[name+'_saved'],chk[name+'_raw'],atol=1e-6),name
 lookup.to_csv(ROOT/'observation_lookup.csv',index=False)
 folds=[];selection=[]
 for seed in [2026,2027,2028]:
  for fold in range(5):
   dest=BASE/f'results_{seed}'/f'seed_{seed}'/f'fold_{fold}'
   test0=pd.read_csv(dest/'predictions.csv');test=enrich(test0.drop(columns=['history_weight']),lookup)
   cal0=pd.read_csv(dest/'calibration_predictions.csv');cal=enrich(cal0.drop(columns=['history_weight']),lookup)
   core=pd.read_csv(dest/'core_expert_oof.csv')
   assert not set(core.patient_id)&set(cal.patient_id)
   assert not set(core.patient_id)&set(test.patient_id)
   output=test0.copy()
   for mode in protocol['modes']:
    for kind in protocol['objectives']:
     options=[]
     for reg in protocol['penalties']:
      pieces=[]
      for meta in range(3):
       tr=pd.read_csv(dest/f'meta_{meta}_expert_crossfit.csv');va=pd.read_csv(dest/f'meta_{meta}_validation_experts.csv')
       assert not set(tr.patient_id)&set(va.patient_id)
       gate=Gate(mode,kind,reg).fit(tr);z=va[['patient_id','target']].copy();z['prediction']=gate.predict(va);pieces.append(z)
      z=pd.concat(pieces);ap,br=score(z,z.prediction);options.append((ap,reg,br));selection.append({'seed':seed,'fold':fold,'mode':mode,'objective':kind,'penalty':reg,'source_AP':ap,'source_Brier':br})
     ap,reg,br=max(options,key=lambda t:(t[0],t[1]));gate=Gate(mode,kind,reg).fit(core);name=f'{mode}_{kind}'
     pred=gate.predict(test);output[name]=pred;output[name+'_cal']=calibrate(cal,gate.predict(cal),test,pred)
   output.to_csv(ROOT/f'fold_{seed}_{fold}.csv',index=False);folds.append(output)
   pd.DataFrame(selection).to_csv(ROOT/'source_selection.csv',index=False)
   print('completed',seed,fold,flush=True)
 raw=pd.concat(folds);cols=['RF_current','OAF','Global_AP','Fixed_half','Unshrunk_gate']+[m+'_'+k for m in protocol['modes'] for k in protocol['objectives']];cols+= [c+'_cal' for c in cols]
 dev=raw[raw.cohort.eq('xuhui_oof')];ext=raw[raw.cohort.eq('fengxian')].groupby(['seed','patient_id','stage_id','target','cohort'],as_index=False)[cols].mean()
 ens=pd.concat([dev[['seed','patient_id','stage_id','target','cohort',*cols]],ext]).groupby(['patient_id','stage_id','target','cohort'],as_index=False)[cols].mean()
 ens.to_csv(ROOT/'ensemble_predictions.csv',index=False);rows=[]
 for cohort,m in ens.groupby('cohort'):
  w=patient_weights(m.patient_id.to_numpy())
  for name in cols:
   ap,br=score(m,m[name]);rows.append({'cohort':cohort,'model':name,'AUPRC':ap,'AUROC':roc_auc_score(m.target,m[name],sample_weight=w),'Brier':br})
 pd.DataFrame(rows).to_csv(ROOT/'metrics.csv',index=False);print(pd.DataFrame(rows).round(5).to_string(index=False))
if __name__=='__main__':main()
