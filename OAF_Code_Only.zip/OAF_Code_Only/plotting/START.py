"""One-click drawing of Figures 2–5 and supplementary figures."""
from pathlib import Path
import runpy
if __name__ == '__main__':
    runpy.run_path(str(Path(__file__).resolve().with_name('DRAW_FIGURES.py')),run_name='__main__')
