"""Fully nested RF/GRU-D OAF plus independently held-out calibration.
Each outer training pool reserves 20% patients for calibration. Gate selection
CV regenerates expert cross-fitting solely inside each meta training subset.
No outer-validation or calibration patient is used for expert/gate selection.
"""
from pathlib import Path
import argparse,json,hashlib,pickle,time,sys
import numpy as np,pandas as pd,torch
from sklearn.model_selection import StratifiedKFold,train_test_split
from sklearn.linear_model import LogisticRegression
from scipy.special import logit,expit
from run_nested import load_data,fit_experts,expert_predictions,model_for,metrics
from fusion import Fusion,patient_weights,loss

NAMES=['RF_current','GRUD','Fixed_half','Global_weight','Unshrunk_gate','OAF','OAF_AP','Global_AP']
GRID=[0.,.01,.05,.2,1.]

def atomic_csv(df,path):
 df.to_csv(path.with_suffix('.tmp'),index=False);path.with_suffix('.tmp').replace(path)

def patient_folds(ids,p,seed):
 labels=p.set_index('patient_id').loc[ids,'outcome_binary'].to_numpy(int)
 return [(ids[a],ids[b]) for a,b in StratifiedKFold(3,shuffle=True,random_state=seed).split(ids,labels)]

def pack_predictions(m,c,h,o,r):
 m=m.copy();m['current']=c;m['history']=h;m['reliability']=r
 for j in range(6):m[f'obs_{j}']=o[:,j]
 return m

def fit_cached(ids,p,e,q,args,seed,fixed_epochs=None):
 key=hashlib.sha256(json.dumps({'ids':sorted(map(int,ids)),'seed':int(seed),'epochs':args.epochs,'hidden':args.hidden,'trees':args.trees,'fixed_epochs':fixed_epochs}).encode()).hexdigest()[:20]
 dest=args.output/'expert_cache'/key;dest.mkdir(parents=True,exist_ok=True)
 if (dest/'complete.json').exists():
  saved=pickle.load(open(dest/'rf_prep.pkl','rb'));net=model_for(saved['prep'],args.hidden)
  net.load_state_dict(torch.load(dest/'grud.pt',map_location='cpu',weights_only=True))
  record=json.loads((dest/'complete.json').read_text());return saved['rf'],net,saved['prep'],record['epochs'],key
 print('EXPERT',key,'patients',len(ids),flush=True)
 rf,grud,prep,epoch,hist=fit_experts(p,e,q,ids,seed,args,fixed_epochs is None,fixed_epochs)
 pickle.dump({'rf':rf,'prep':prep},open(dest/'rf_prep.pkl','wb'));torch.save(grud.state_dict(),dest/'grud.pt')
 (dest/'complete.json').write_text(json.dumps({'fit_ids':list(map(int,ids)),'seed':int(seed),'epochs':int(epoch),'epoch_history':hist},indent=2))
 return rf,grud,prep,int(epoch),key

def predicted(ids,rf,grud,prep,p,e,q):
 m,c,h,o,r,_=expert_predictions(rf,grud,prep,p,e,q,ids);return pack_predictions(m,c,h,o,r)

def get_arrays(m):
 return m.current.to_numpy(),m.history.to_numpy(),m[[f'obs_{j}' for j in range(6)]].to_numpy(),m.reliability.to_numpy(),m.target.to_numpy(),m.patient_id.to_numpy()

def gate_models(m,strength,ap_strength,global_alpha):
 c,h,o,r,y,ids=get_arrays(m)
 global_ap=Fusion('fixed_half').fit(c,h,o,r,y,ids);global_ap.alpha=global_alpha
 return {'Fixed_half':Fusion('fixed_half').fit(c,h,o,r,y,ids),'Global_weight':Fusion('global').fit(c,h,o,r,y,ids),
         'Unshrunk_gate':Fusion('shrink',0).fit(c,h,o,r,y,ids),'OAF':Fusion('shrink',strength).fit(c,h,o,r,y,ids),
         'OAF_AP':Fusion('shrink',ap_strength).fit(c,h,o,r,y,ids),'Global_AP':global_ap}

def output_predictions(m,gates):
 c,h,o,r,y,ids=get_arrays(m);out=m[['patient_id','stage_id','target','center_id']].copy()
 out['RF_current']=c;out['GRUD']=h
 for name,g in gates.items():out[name]=g.predict(c,h,o,r)
 out['history_weight']=gates['OAF'].gates(o,r)
 return out

def calibrated(cal,test):
 out=test.copy();pars={};w=patient_weights(cal.patient_id.to_numpy())
 for name in NAMES:
  # Positive slope preserves ranking within each fitted outer model. A bounded
  # weighted logistic fit prevents a target-independent source fit reversing risk.
  from scipy.optimize import minimize
  x=logit(np.clip(cal[name].to_numpy(),1e-6,1-1e-6));y=cal.target.to_numpy()
  def objective(beta):
   z=beta[0]+beta[1]*x
   return np.average(np.logaddexp(0,z)-y*z,weights=w)+1e-4*np.sum(beta**2)
  result=minimize(objective,[0.,1.],method='L-BFGS-B',bounds=[(None,None),(0,None)])
  assert result.success and np.isfinite(result.fun)
  out[name+'_cal']=expit(result.x[0]+result.x[1]*logit(np.clip(test[name].to_numpy(),1e-6,1-1e-6)))
  pars[name]={'intercept':float(result.x[0]),'slope':float(result.x[1]),'optimizer_success':bool(result.success)}
 return out,pars

def aggregate(args):
 files=sorted(args.output.glob('seed_*/fold_*/predictions.csv'));frames=[pd.read_csv(p) for p in files]
 if not frames:return
 raw=pd.concat(frames,ignore_index=True);atomic_csv(raw,args.output/'fold_predictions.csv')
 columns=NAMES+[n+'_cal' for n in NAMES]
 dev=raw[raw.cohort.eq('xuhui_oof')]
 ext=raw[raw.cohort.eq('fengxian')].groupby(['seed','patient_id','stage_id','target','cohort'],as_index=False)[columns].mean()
 byseed=pd.concat([dev[['seed','patient_id','stage_id','target','cohort',*columns]],ext],ignore_index=True)
 assert not byseed.duplicated(['seed','cohort','patient_id','stage_id']).any()
 atomic_csv(byseed,args.output/'predictions_by_seed.csv')
 ens=byseed.groupby(['patient_id','stage_id','target','cohort'],as_index=False)[columns].mean()
 atomic_csv(ens,args.output/'ensemble_predictions.csv')
 rows=[]
 for cohort,g in ens.groupby('cohort'):
  for name in columns:rows.append({'cohort':cohort,'model':name,'patients':g.patient_id.nunique(),'queries':len(g),**metrics(g,name)})
 atomic_csv(pd.DataFrame(rows),args.output/'metrics.csv');print(pd.DataFrame(rows).round(4).to_string(index=False),flush=True)

def main(args):
 torch.set_num_threads(args.threads);args.output.mkdir(parents=True,exist_ok=True)
 protocol={'outer_folds':5,'seeds':args.seeds,'gate_selection_folds':3,'expert_crossfit_folds_inside_gate_training':3,'calibration_fraction':.2,
 'calibration':'separate source patients never used in expert or gate fitting; monotone weighted logistic with 1e-4 ridge','gate_grid':GRID,
 'epoch_max':args.epochs,'epoch_patience':args.patience,'hidden':args.hidden,'trees':args.trees,
 'evaluation':'patient equal; development outer OOF; exploratory target mean outer-model predictions',
 'difference_from_old':'independent calibration holdout reduces expert training pool; gate-selection experts regenerated within each meta fold',
 'target_labels_used_for_selection':False,'timestamped_endpoint':'eventual delivery intervention','torch_version':torch.__version__}
 proto=args.output/'protocol.json'
 if proto.exists():assert json.loads(proto.read_text())==protocol,'Protocol/cache mismatch'
 proto.write_text(json.dumps(protocol,indent=2))
 p,e,q,f=load_data(args.processed);external=p.loc[p.eligible&p.site.eq('fengxian'),'patient_id'].to_numpy(int)
 for seed in args.seeds:
  for fold in range(5):
   dest=args.output/f'seed_{seed}'/f'fold_{fold}';dest.mkdir(parents=True,exist_ok=True)
   if (dest/'complete.json').exists():print('CACHE OUTER',seed,fold,flush=True);continue
   start=time.monotonic();train=f.loc[f.fold.ne(fold),'patient_id'].to_numpy(int);valid=f.loc[f.fold.eq(fold),'patient_id'].to_numpy(int)
   labels=p.set_index('patient_id').loc[train,'outcome_binary'].to_numpy(int)
   core,calids=train_test_split(train,test_size=.2,stratify=labels,random_state=seed+fold+8000)
   sets=[set(core),set(calids),set(valid),set(external)]
   assert all(not sets[i]&sets[j] for i in range(4) for j in range(i))
   audit={'outer_training_ids':train.tolist(),'core_training_ids':core.tolist(),'calibration_ids':calids.tolist(),'outer_validation_ids':valid.tolist(),'target_ids':external.tolist(),'meta_folds':[]}
   meta_oof=[];candidate_rows=[];epoch_choices=[];candidate_preds={k:[] for k in GRID}
   for meta,(mt,mv) in enumerate(patient_folds(core,p,seed+fold+40)):
    assert not set(mt)&set(mv);mrecord={'training_ids':mt.tolist(),'validation_ids':mv.tolist(),'expert_crossfits':[]}
    inners=[]
    for inner,(it,iv) in enumerate(patient_folds(mt,p,seed+fold+meta+900)):
     assert not set(it)&set(iv) and not (set(it)|set(iv))&set(mv)
     rf,grud,prep,epoch,key=fit_cached(it,p,e,q,args,seed+fold*10000+meta*1000+inner*10)
     pred=predicted(iv,rf,grud,prep,p,e,q);inners.append(pred)
     mrecord['expert_crossfits'].append({'fit_ids':it.tolist(),'prediction_ids':iv.tolist(),'cache_key':key,'epoch':epoch})
    meta_train=pd.concat(inners,ignore_index=True);assert set(meta_train.patient_id)==set(mt)
    atomic_csv(meta_train,dest/f'meta_{meta}_expert_crossfit.csv')
    rf,grud,prep,epoch,key=fit_cached(mt,p,e,q,args,seed+fold*10000+meta*1000+999)
    meta_val=predicted(mv,rf,grud,prep,p,e,q);meta_oof.append(meta_val);epoch_choices.append(epoch)
    atomic_csv(meta_val,dest/f'meta_{meta}_validation_experts.csv');mrecord['validation_expert_fit_ids']=mt.tolist();mrecord['validation_expert_cache']=key
    c,h,o,r,y,ids=get_arrays(meta_train);vc,vh,vo,vr,vy,vids=get_arrays(meta_val)
    for strength in GRID:
     g=Fusion('shrink',strength).fit(c,h,o,r,y,ids)
     pred=g.predict(vc,vh,vo,vr)
     candidate_preds[strength].append(pd.DataFrame({"patient_id":vids,"target":vy,"pred":pred}))
     for patient in np.unique(vids):
      ix=vids==patient
      candidate_rows.append({'meta':meta,'strength':strength,'patient_id':int(patient),'brier':float(np.mean((vy[ix]-pred[ix])**2))})
    audit['meta_folds'].append(mrecord)
    (dest/'progress.json').write_text(json.dumps(audit,indent=2));print('META COMPLETE',seed,fold,meta,flush=True)
   cand=pd.DataFrame(candidate_rows);atomic_csv(cand,dest/'gate_candidate_patient_brier.csv')
   score=cand.groupby('strength').brier.mean();strength=min(GRID,key=lambda x:(score.loc[x],-x))
   meta_all=pd.concat(meta_oof,ignore_index=True);assert set(meta_all.patient_id)==set(core)
   atomic_csv(meta_all,dest/'core_expert_oof.csv')
   from sklearn.metrics import average_precision_score
   aps={}
   for k in GRID:
    z=pd.concat(candidate_preds[k],ignore_index=True);aps[k]=float(average_precision_score(z.target,z.pred,sample_weight=patient_weights(z.patient_id.to_numpy())))
   ap_strength=max(GRID,key=lambda k:(aps[k],k))
   global_scores={}
   for a in [0.,.1,.25,.5,.75,1.]:
    z=meta_all.current+a*(meta_all.history-meta_all.current)
    global_scores[a]=float(average_precision_score(meta_all.target,z,sample_weight=patient_weights(meta_all.patient_id.to_numpy())))
   global_alpha=max(global_scores,key=lambda a:(global_scores[a],-a))
   atomic_csv(pd.DataFrame({'strength':list(aps),'meta_auprc':list(aps.values())}),dest/'ap_selection.csv')
   audit.update({'selected_AP_strength':ap_strength,'selected_global_AP_weight':global_alpha,'selection_rule':'source-meta-validation only'})
   gates=gate_models(meta_all,strength,ap_strength,global_alpha)
   epoch=int(np.median(epoch_choices));rf,grud,prep,_,key=fit_cached(core,p,e,q,args,seed+fold*10000+9999,epoch)
   cal=output_predictions(predicted(calids,rf,grud,prep,p,e,q),gates);atomic_csv(cal,dest/'calibration_predictions.csv')
   frames=[]
   for cohort,ids in [('xuhui_oof',valid),('fengxian',external)]:
    test=output_predictions(predicted(ids,rf,grud,prep,p,e,q),gates);test,pars=calibrated(cal,test)
    test['cohort']=cohort;test['fold']=fold;test['seed']=seed;frames.append(test)
   audit.update({'selected_strength':strength,'gate_selection_brier':score.to_dict(),'outer_refit_epochs':epoch,'final_expert_cache':key,'calibration_params':pars,'elapsed_seconds':time.monotonic()-start})
   pickle.dump(gates,open(dest/'gates.pkl','wb'))
   atomic_csv(pd.concat(frames,ignore_index=True),dest/'predictions.csv');(dest/'complete.json').write_text(json.dumps(audit,indent=2))
   aggregate(args);print('OUTER COMPLETE',seed,fold,'seconds',round(time.monotonic()-start,1),flush=True)
 aggregate(args);(args.output/'RUN_COMPLETE.json').write_text(json.dumps({'seeds':args.seeds,'folds':5},indent=2))

if __name__=='__main__':
 root=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser()
 ap.add_argument('--processed',type=Path,default=root/'processed');ap.add_argument('--output',type=Path,default=root/'results');ap.add_argument('--seeds',type=int,nargs='+',default=[2026]);ap.add_argument('--epochs',type=int,default=60);ap.add_argument('--patience',type=int,default=10);ap.add_argument('--hidden',type=int,default=128);ap.add_argument('--trees',type=int,default=500);ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--threads',type=int,default=2)
 main(ap.parse_args())
