"""Independent simulation + paired patient/mask resampling. No target tuning.
Run: python run_experiments.py --source PATH --replicates 24 --bootstrap 2000
Synthetic data are NOT clinical observations. CI across simulations is Monte
Carlo uncertainty of the mean. Real-data CI is conditional on fitted scores.
"""
from pathlib import Path
import argparse,json,sys,time
import numpy as np,pandas as pd
from scipy.special import expit
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import average_precision_score,roc_auc_score,brier_score_loss
from sklearn.linear_model import LogisticRegression
from scipy.optimize import minimize

def metric(y,p,w=None):
 return dict(AUPRC=average_precision_score(y,p,sample_weight=w),AUROC=roc_auc_score(y,p,sample_weight=w),Brier=brier_score_loss(y,p,sample_weight=w))

def generate(n,rng,history=True,shift=0):
 s=rng.normal(size=(n,4));d=rng.normal(size=(n,3))
 risk=-.9+1.1*s[:,0]-.7*s[:,1]+.4*s[:,2]*s[:,3]
 if history:risk+=.9*d[:,0]-.6*d[:,1]+.35*d[:,2]*s[:,0]
 y=rng.binomial(1,expit(risk))
 # Reassessment depends on latent clinical severity. The policy reverses with
 # shift; it is not a hospital label, and never enters outcome generation.
 opportunity=expit(.2+(1-2*shift)*(.9*risk+.4*s[:,0]))
 m=rng.binomial(1,opportunity[:,None],size=(n,3))
 noise=.2+.8*(1-opportunity)
 observed=d+rng.normal(size=(n,3))*noise[:,None]
 observed*=m
 counts=m*(2+rng.poisson(1+2*opportunity[:,None],size=(n,3)))
 recency=rng.exponential(1/(.4+opportunity[:,None]),size=(n,3))
 obs=np.column_stack([np.mean(m,axis=1),np.log1p(counts.sum(1)),
 np.log1p(recency.mean(1)),m[:,0],m[:,1],m[:,2]])
 return s,np.column_stack([s,observed,m,np.log1p(counts),np.log1p(recency)]),obs,y

def simulations(out,reps,fusion_module):
 from fusion import Fusion,select_gate
 rows=[];tuning=[]
 for rep in range(reps):
  for scenario,hist,target_shift in [('stable_informative',True,0),('policy_shift_informative',True,1),('redundant_history',False,1)]:
   rng=np.random.default_rng(87000+rep*101+int(not hist)*2000)
   st,ht,ot,yt=generate(640,rng,hist,0)
   sm,hm,om,ym=generate(240,rng,hist,0)
   current=RandomForestClassifier(n_estimators=160,min_samples_leaf=8,max_features=.8,random_state=rep,n_jobs=2).fit(st,yt)
   history=RandomForestClassifier(n_estimators=160,min_samples_leaf=8,max_features=.8,random_state=rep,n_jobs=2).fit(ht,yt)
   c=current.predict_proba(sm)[:,1];h=history.predict_proba(hm)[:,1];ids=np.arange(len(ym));r=np.ones(len(ym))
   gate,records=select_gate('shrink',c,h,om,r,ym,ids,rep+400)
   un=Fusion('shrink',0).fit(c,h,om,r,ym,ids)
   glob=Fusion('global').fit(c,h,om,r,ym,ids)
   # Calibration is fitted only on independent source meta patients, and is
   # never fitted to either evaluation set.
   raw=gate.predict(c,h,om,r)
   cal=LogisticRegression(C=1e3).fit(np.log(np.clip(raw,1e-6,1-1e-6)/(1-np.clip(raw,1e-6,1-1e-6))).reshape(-1,1),ym)
   tuning.append(dict(rep=rep,scenario=scenario,strength=gate.strength,global_weight=glob.alpha,meta_tuning=records))
   for site,shift in [('source_test',0),('shifted_test',target_shift)]:
    ss,hh,oo,yy=generate(1000,rng,hist,shift)
    cc=current.predict_proba(ss)[:,1];hp=history.predict_proba(hh)[:,1]
    p=gate.predict(cc,hp,oo,np.ones(len(yy)))
    probs={'Current_RF':cc,'History_RF':hp,'Fixed_half':.5*(cc+hp),'Global_weight':glob.predict(cc,hp,oo,np.ones(len(yy))),
     'Unshrunk_gate':un.predict(cc,hp,oo,np.ones(len(yy))),'OAF':p,
     'Calibrated_OAF':cal.predict_proba(np.log(np.clip(p,1e-6,1-1e-6)/(1-np.clip(p,1e-6,1-1e-6))).reshape(-1,1))[:,1]}
    for name,pred in probs.items():rows.append(dict(rep=rep,scenario=scenario,site=site,model=name,**metric(yy,pred)))
   pd.DataFrame(rows).to_csv(out/'simulation_replicates.csv',index=False)
  print('Simulation',rep+1,'/',reps,flush=True)
 pd.DataFrame(rows).to_csv(out/'simulation_replicates.csv',index=False)
 (out/'simulation_tuning.json').write_text(json.dumps(tuning,indent=2))
 d=pd.DataFrame(rows);s=[];contr=[]
 for keys,g in d.groupby(['scenario','site','model']):
  for m in ['AUPRC','AUROC','Brier']:
   v=g[m].to_numpy();se=v.std(ddof=1)/np.sqrt(len(v))
   s.append(dict(zip(['scenario','site','model'],keys),metric=m,mean=v.mean(),sd=v.std(ddof=1),mean_ci_low=v.mean()-1.96*se,mean_ci_high=v.mean()+1.96*se,n=len(v)))
 for (scenario,site),g in d.groupby(['scenario','site']):
  for m in ['AUPRC','AUROC','Brier']:
   pv=g.pivot(index='rep',columns='model',values=m)
   for ref in ['Current_RF','History_RF','Fixed_half','Global_weight','Unshrunk_gate']:
    v=(pv.OAF-pv[ref]).to_numpy();se=v.std(ddof=1)/np.sqrt(len(v))
    contr.append(dict(scenario=scenario,site=site,contrast='OAF - '+ref,metric=m,mean=v.mean(),ci_low=v.mean()-1.96*se,ci_high=v.mean()+1.96*se,n=len(v)))
 pd.DataFrame(s).to_csv(out/'simulation_summary.csv',index=False);pd.DataFrame(contr).to_csv(out/'simulation_paired_effects.csv',index=False)

def real_stress(source,out,B):
 base=pd.read_csv(source/'private_predictions/common_common_predictions.csv')
 stress=pd.read_csv(source/'private_predictions/common_stress_predictions.csv')
 models=['RF_current','D','Fixed_half','Global_weight','OAF_same6_no_shrink','OAF_shrink']
 rows=[];effects=[];rng=np.random.default_rng(64020)
 for site,b in base.groupby('cohort'):
  b=b.sort_values(['patient_id','stage_id']).reset_index(drop=True)
  ids,inv,counts=np.unique(b.patient_id,return_inverse=True,return_counts=True);w=1/counts[inv];y=b.target.to_numpy()
  for rate in [.2,.4]:
   ss=stress.loc[stress.cohort.eq(site)&stress.dropout.eq(rate)]
   masks=sorted(ss['mask'].unique());arrays={}
   for model in models:
    arrays[model]=np.stack([ss.loc[ss['mask'].eq(mask)].sort_values(['patient_id','stage_id'])[model].to_numpy() for mask in masks])
   for mask in masks:
    aligned=ss.loc[ss['mask'].eq(mask)].sort_values(['patient_id','stage_id'])
    assert np.array_equal(aligned[['patient_id','stage_id','target']].values,b[['patient_id','stage_id','target']].values)
    assert np.allclose(aligned.RF_current,b.RF_current,atol=1e-14)
   from fast_metric import Prepared
   prepared={model:[Prepared(y,p,b[model].to_numpy()) for p in arrays[model]] for model in models}
   draws={model:{m:[] for m in ['AUPRC','AUROC','Brier','response']} for model in models}
   for iteration in range(B):
    pc=rng.multinomial(len(ids),np.full(len(ids),1/len(ids)));ww=w*pc[inv]
    pick=rng.integers(0,len(masks),len(masks))
    for model in models:
     # Average metric across sampled masks; NOT metric of averaged predictions.
     vals=np.array([prep.values(ww) for prep in prepared[model]])
     means=vals[pick].mean(0)
     for m,v in zip(['AUPRC','AUROC','Brier','response'],means):draws[model][m].append(v)
    if iteration%500==0:print('Real bootstrap',site,rate,iteration,flush=True)
   for model in models:
    point=np.array([prep.values(w) for prep in prepared[model]]).mean(0)
    for m,v in zip(['AUPRC','AUROC','Brier','response'],point):
     lo,hi=np.quantile(draws[model][m],[.025,.975]);rows.append(dict(site=site,dropout=rate,model=model,metric=m,mean=v,ci_low=lo,ci_high=hi,bootstrap=B,masks=len(masks)))
   for ref in ['RF_current','D','Fixed_half','Global_weight','OAF_same6_no_shrink']:
    for m in ['AUPRC','AUROC','Brier','response']:
     a=next(x['mean'] for x in rows if x['site']==site and x['dropout']==rate and x['model']=='OAF_shrink' and x['metric']==m)
     c=next(x['mean'] for x in rows if x['site']==site and x['dropout']==rate and x['model']==ref and x['metric']==m)
     lo,hi=np.quantile(np.asarray(draws['OAF_shrink'][m])-draws[ref][m],[.025,.975])
     effects.append(dict(site=site,dropout=rate,contrast='OAF - '+ref,metric=m,mean=a-c,ci_low=lo,ci_high=hi))
   pd.DataFrame(rows).to_csv(out/'real_stress_summary.csv',index=False);pd.DataFrame(effects).to_csv(out/'real_stress_paired_effects.csv',index=False)
 return rows,effects

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--source',type=Path,required=True);a.add_argument('--replicates',type=int,default=24);a.add_argument('--bootstrap',type=int,default=2000);a.add_argument('--only',choices=['simulation','stress','all'],default='all');args=a.parse_args();out=Path(__file__).resolve().parent
 sys.path.insert(0,str(args.source/'code'))
 (out/'protocol.json').write_text(json.dumps({'seed_simulation':87000,'seed_resampling':64020,'replicates':args.replicates,'patient_bootstrap':args.bootstrap,'simulation_train':640,'simulation_meta':240,'simulation_test_per_domain':1000,'gate_strength_grid':[0,.01,.05,.2,1],'selection':'source meta patient CV Brier','target_labels_used_in_fitting':False,'real_analysis':'conditional on archived fitted predictions; independently resample patients and shared masks','simulation_scenarios':['stable_informative','policy_shift_informative','redundant_history']},indent=2))
 if args.only in ['simulation','all']:simulations(out,args.replicates,args.source/'code')
 if args.only in ['stress','all']:real_stress(args.source,out,args.bootstrap)
