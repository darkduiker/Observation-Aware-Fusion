"""Leakage-safe landmark dataset for OPAL-Fusion."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math
import re
from typing import Iterable

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from sklearn.cluster import KMeans

from .labor_schema import MODEL_EVENT_SPECS as EVENT_SPECS


STAGE_IDS = {"lt4": 0, "4to6": 1, "6to10": 2}
CENTER_IDS = {"xuhui": 0, "fengxian": 1, "mixed_source_excluded": 2}
TIME_QUALITY_IDS = {
    "invalid": 0,
    "missing": 0,
    "native_timestamp": 1,
    "parsed_text": 2,
    "excel_serial": 3,
    "excel_serial_text": 4,
}

STATIC_COLUMNS = (
    "年龄",
    "身高（m）",
    "体重(kg)",
    "产时BMI",
    "孕周",
    "孕次",
    "产次",
    "既往剖宫产（0/1）",
    "既往盆底或骨盆手术（0/1）",
    "双顶径（mm）",
    "精神心理（爱丁堡）",
)


def _numeric(value) -> float:
    if pd.isna(value):
        return np.nan
    text = str(value).strip().replace("，", ".").replace(",", ".")
    try:
        return float(text)
    except ValueError:
        return np.nan


def _gestational_weeks(value) -> float:
    if pd.isna(value):
        return np.nan
    text = str(value).strip().replace("＋", "+")
    match = re.fullmatch(r"(\d+)(?:\+(\d+))?", text)
    if match is None:
        return _numeric(value)
    weeks = float(match.group(1))
    days = float(match.group(2) or 0)
    return weeks + days / 7.0


def static_vector(row: pd.Series) -> np.ndarray:
    output = []
    for column in STATIC_COLUMNS:
        parser = _gestational_weeks if column == "孕周" else _numeric
        output.append(parser(row.get(column)))
    return np.asarray(output, dtype=np.float32)


@dataclass
class LaborPreprocessor:
    variable_to_id: dict[str, int]
    event_mean: dict[str, float]
    event_std: dict[str, float]
    static_mean: np.ndarray
    static_std: np.ndarray

    @classmethod
    def fit(
        cls,
        patients: pd.DataFrame,
        events: pd.DataFrame,
        train_patient_ids: Iterable[int],
    ) -> "LaborPreprocessor":
        train_ids = set(map(int, train_patient_ids))
        variable_names = [spec.name for spec in EVENT_SPECS if spec.enabled]
        variable_to_id = {name: index + 1 for index, name in enumerate(variable_names)}
        train_events = events.loc[
            events["patient_id"].isin(train_ids)
            & events["enabled"].astype(bool)
            & events["variable"].isin(variable_names)
        ]
        event_mean: dict[str, float] = {}
        event_std: dict[str, float] = {}
        for variable in variable_names:
            values = pd.to_numeric(
                train_events.loc[train_events["variable"] == variable, "value"],
                errors="coerce",
            ).dropna()
            mean = 0.0 if variable.startswith("fetal_position_") else (float(values.mean()) if len(values) else 0.0)
            std = 1.0 if variable.startswith("fetal_position_") else (float(values.std(ddof=0)) if len(values) else 1.0)
            event_mean[variable] = mean
            event_std[variable] = std if std > 1e-6 else 1.0

        patient_rows = patients.loc[patients["patient_id"].isin(train_ids)].set_index("patient_id")
        static_matrix = np.stack([static_vector(row) for _, row in patient_rows.iterrows()])
        static_mean = np.nanmean(static_matrix, axis=0)
        static_std = np.nanstd(static_matrix, axis=0)
        static_mean = np.where(np.isfinite(static_mean), static_mean, 0.0).astype(np.float32)
        static_std = np.where((np.isfinite(static_std)) & (static_std > 1e-6), static_std, 1.0).astype(np.float32)
        return cls(variable_to_id, event_mean, event_std, static_mean, static_std)

    @property
    def n_variables(self) -> int:
        return len(self.variable_to_id)

    @property
    def n_static_features(self) -> int:
        return len(STATIC_COLUMNS)

    @property
    def n_policy_features(self) -> int:
        return 2 * self.n_variables + 4

    def normalize_event(self, variable: str, value: float) -> float:
        return (float(value) - self.event_mean[variable]) / self.event_std[variable]

    def normalize_static(self, row: pd.Series) -> tuple[np.ndarray, np.ndarray]:
        values = static_vector(row)
        missing = ~np.isfinite(values)
        normalized = (np.where(missing, self.static_mean, values) - self.static_mean) / self.static_std
        return normalized.astype(np.float32), missing.astype(np.float32)


@dataclass(frozen=True)
class PolicyDomainAssigner:
    """Stage-conditional training acquisition environments.

    Clustering within stage prevents the domain adversary from treating normal
    labor progression as an acquisition-policy shift. Clusters are ordered by
    total event count so their integer labels have a consistent interpretation.
    """

    centroids: np.ndarray
    feature_mean: np.ndarray
    feature_std: np.ndarray

    @classmethod
    def fit(
        cls,
        policy_features: np.ndarray,
        stage_ids: np.ndarray,
        n_domains: int = 3,
        n_stages: int = 3,
        seed: int = 2026,
    ) -> "PolicyDomainAssigner":
        all_centroids = []
        all_means = []
        all_stds = []
        count_feature_index = policy_features.shape[1] - 4
        for stage_id in range(n_stages):
            stage_features = policy_features[np.asarray(stage_ids) == stage_id]
            if len(stage_features) < n_domains:
                raise ValueError(f"Stage {stage_id} has fewer samples than policy domains")
            feature_mean = np.mean(stage_features, axis=0)
            feature_std = np.std(stage_features, axis=0)
            feature_std = np.where(feature_std > 1e-6, feature_std, 1.0)
            normalized = (stage_features - feature_mean) / feature_std
            kmeans = KMeans(n_clusters=n_domains, random_state=seed + stage_id, n_init=20)
            kmeans.fit(normalized)
            original_centroids = kmeans.cluster_centers_
            original_count = (
                original_centroids[:, count_feature_index] * feature_std[count_feature_index]
                + feature_mean[count_feature_index]
            )
            order = np.argsort(original_count)
            all_centroids.append(original_centroids[order])
            all_means.append(feature_mean)
            all_stds.append(feature_std)
        return cls(
            centroids=np.asarray(all_centroids, dtype=np.float32),
            feature_mean=np.asarray(all_means, dtype=np.float32),
            feature_std=np.asarray(all_stds, dtype=np.float32),
        )

    @property
    def n_domains(self) -> int:
        return int(self.centroids.shape[1])

    def predict_one(self, policy_features: np.ndarray, stage_id: int) -> int:
        normalized = (
            policy_features - self.feature_mean[stage_id]
        ) / self.feature_std[stage_id]
        squared_distance = np.sum(
            (self.centroids[stage_id] - normalized[None, :]) ** 2,
            axis=1,
        )
        return int(np.argmin(squared_distance))


class LaborLandmarkDataset(Dataset):
    def __init__(
        self,
        patients: pd.DataFrame,
        events: pd.DataFrame,
        landmarks: pd.DataFrame,
        preprocessor: LaborPreprocessor,
        patient_ids: Iterable[int] | None = None,
        stages: Iterable[str] = ("lt4", "4to6", "6to10"),
        target_column: str = "outcome_binary",
        policy_domain_assigner: PolicyDomainAssigner | None = None,
    ) -> None:
        self.preprocessor = preprocessor
        self.target_column = target_column
        self.policy_domain_assigner = policy_domain_assigner
        self.patient_lookup = patients.set_index("patient_id", drop=False)
        selected = landmarks.loc[landmarks["stage"].astype(str).isin(set(stages))].copy()
        if patient_ids is not None:
            selected = selected.loc[selected["patient_id"].isin(set(map(int, patient_ids)))]
        selected["query_time"] = pd.to_datetime(selected["query_time"], errors="coerce", format="mixed")
        self.landmarks = selected.loc[selected["query_time"].notna()].reset_index(drop=True)
        prepared_events = events.loc[
            events["enabled"].astype(bool)
            & events["variable"].isin(preprocessor.variable_to_id)
        ].copy()
        prepared_events["event_time"] = pd.to_datetime(prepared_events["event_time"], errors="coerce", format="mixed")
        self.events_by_patient = {
            int(patient_id): group.sort_values(["event_time", "source_row", "variable"]).reset_index(drop=True)
            for patient_id, group in prepared_events.groupby("patient_id", sort=False)
        }

    def __len__(self) -> int:
        return len(self.landmarks)

    @lru_cache(maxsize=4096)
    def __getitem__(self, index: int) -> dict[str, np.ndarray | int]:
        landmark = self.landmarks.iloc[index]
        patient_id = int(landmark["patient_id"])
        query_time = pd.Timestamp(landmark["query_time"])
        patient_events = self.events_by_patient.get(patient_id, pd.DataFrame())
        if not patient_events.empty:
            history = patient_events.loc[patient_events["event_time"] <= query_time].copy()
        else:
            history = patient_events

        if not history.empty and (history["event_time"] > query_time).any():
            raise AssertionError("Future-information leakage in event history")

        if history.empty:
            value = np.empty(0, dtype=np.float32)
            variable_id = np.empty(0, dtype=np.int64)
            modality_id = np.empty(0, dtype=np.int64)
            recency = np.empty(0, dtype=np.float32)
            elapsed = np.empty(0, dtype=np.float32)
            quality_id = np.empty(0, dtype=np.int64)
        else:
            first_time = history["event_time"].min()
            value = np.asarray([
                self.preprocessor.normalize_event(row.variable, row.value)
                for row in history.itertuples(index=False)
            ], dtype=np.float32)
            variable_id = history["variable"].map(self.preprocessor.variable_to_id).to_numpy(np.int64)
            modality_id = np.ones(len(history), dtype=np.int64)  # ultrasound event modality
            recency = ((query_time - history["event_time"]).dt.total_seconds() / 3600).to_numpy(np.float32)
            elapsed = ((history["event_time"] - first_time).dt.total_seconds() / 3600).to_numpy(np.float32)
            quality_id = history["time_quality"].map(TIME_QUALITY_IDS).fillna(0).to_numpy(np.int64)

        counts = np.zeros(self.preprocessor.n_variables, dtype=np.float32)
        if len(variable_id):
            for identifier in variable_id:
                counts[int(identifier) - 1] += 1.0
        availability = (counts > 0).astype(np.float32)
        span = float(elapsed.max()) if len(elapsed) else 0.0
        mean_recency = float(recency.mean()) if len(recency) else 0.0
        max_recency = float(recency.max()) if len(recency) else 0.0
        policy = np.concatenate([
            availability,
            np.log1p(counts),
            np.asarray([math.log1p(len(value)), span, mean_recency, max_recency], dtype=np.float32),
        ])

        patient_row = self.patient_lookup.loc[patient_id]
        static, static_missing = self.preprocessor.normalize_static(patient_row)
        target_value = landmark[self.target_column]
        stage_id = STAGE_IDS[str(landmark["stage"])]
        domain_id = (
            self.policy_domain_assigner.predict_one(policy, stage_id)
            if self.policy_domain_assigner is not None
            else 0
        )
        return {
            "patient_id": patient_id,
            "value": value,
            "variable_id": variable_id,
            "modality_id": modality_id,
            "recency_hours": recency,
            "elapsed_hours": elapsed,
            "time_quality_id": quality_id,
            "stage_id": stage_id,
            "center_id": CENTER_IDS[str(landmark["site"])],
            "domain_id": domain_id,
            "static": static,
            "static_missing": static_missing,
            "policy_features": policy.astype(np.float32),
            "variable_available": availability,
            "target": int(target_value),
        }


def collate_landmarks(samples: list[dict]) -> dict[str, torch.Tensor]:
    if not samples:
        raise ValueError("Cannot collate an empty batch")
    batch_size = len(samples)
    max_events = max(1, max(len(sample["value"]) for sample in samples))

    float_event_keys = ["value", "recency_hours", "elapsed_hours"]
    int_event_keys = ["variable_id", "modality_id", "time_quality_id"]
    batch: dict[str, torch.Tensor] = {}
    for key in float_event_keys:
        output = torch.zeros(batch_size, max_events, dtype=torch.float32)
        for row, sample in enumerate(samples):
            length = len(sample[key])
            if length:
                output[row, :length] = torch.as_tensor(sample[key], dtype=torch.float32)
        batch[key] = output
    for key in int_event_keys:
        output = torch.zeros(batch_size, max_events, dtype=torch.long)
        for row, sample in enumerate(samples):
            length = len(sample[key])
            if length:
                output[row, :length] = torch.as_tensor(sample[key], dtype=torch.long)
        batch[key] = output

    padding = torch.ones(batch_size, max_events, dtype=torch.bool)
    for row, sample in enumerate(samples):
        padding[row, : len(sample["value"])] = False
    batch["event_padding_mask"] = padding

    for key in ["stage_id", "center_id", "domain_id", "target", "patient_id"]:
        batch[key] = torch.as_tensor([sample[key] for sample in samples], dtype=torch.long)
    for key in ["static", "static_missing", "policy_features", "variable_available"]:
        batch[key] = torch.as_tensor(np.stack([sample[key] for sample in samples]), dtype=torch.float32)
    return batch


def apply_policy_intervention(
    batch: dict[str, torch.Tensor],
    drop_probability: float = 0.2,
    time_jitter_std_hours: float = 0.1,
) -> dict[str, torch.Tensor]:
    """Simulate a label-preserving change in event acquisition policy."""
    augmented = {key: value.clone() for key, value in batch.items()}
    observed = ~batch["event_padding_mask"]
    random_drop = (torch.rand_like(batch["value"]) < drop_probability) & observed
    augmented["event_padding_mask"] = batch["event_padding_mask"] | random_drop
    if time_jitter_std_hours > 0:
        jitter = torch.randn_like(batch["recency_hours"]) * time_jitter_std_hours
        augmented["recency_hours"] = torch.clamp_min(batch["recency_hours"] + jitter * observed, 0.0)
        augmented["elapsed_hours"] = torch.clamp_min(batch["elapsed_hours"] - jitter * observed, 0.0)
    return augmented
