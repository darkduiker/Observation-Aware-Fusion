"""One Python entry point for the supplemental experiments."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
cmd=[sys.executable,str(root/'run_experiments.py'),'--source',str(root/'input')]+sys.argv[1:]
result=subprocess.run(cmd,cwd=root)
if result.returncode:sys.exit(result.returncode)
subprocess.run([sys.executable,str(root/'make_report.py')],cwd=root,check=True)
print('Finished. See EXPERIMENT_FINDINGS.md and the result CSVs.')
