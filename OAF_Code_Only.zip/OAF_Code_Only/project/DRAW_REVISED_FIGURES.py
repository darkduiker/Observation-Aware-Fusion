"""Regenerate revised Figure 5 and threshold-utility figure from frozen predictions.
Run from any directory; no model refitting. Requires numpy/pandas/sklearn/matplotlib.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score,roc_auc_score,brier_score_loss
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
OUT=Path(__file__).resolve().parent
NESTED=OUT/'nested_validation'
FIG=OUT/'paper/figures'
metrics=pd.read_csv(NESTED/'evaluation/metrics_by_seed_and_ensemble.csv')
metrics=metrics[metrics.seed.eq('ensemble')]
# Extra analyses of already frozen predictions: calibration bins and threshold utility.
pred=pd.read_csv(NESTED/'evaluation/ensemble_predictions.csv')
effects=pd.read_csv(NESTED/'evaluation/paired_ensemble_bootstrap.csv')
checks=[];bins=[];nb=[]
for site,d in pred.groupby('cohort',sort=False):
    counts=d.patient_id.value_counts();w=1/d.patient_id.map(counts).to_numpy();y=d.target.to_numpy()
    for nm in [c for c in pred if c not in ['patient_id','stage_id','target','cohort']]:
        vals={'AUPRC':average_precision_score(y,d[nm],sample_weight=w),'AUROC':roc_auc_score(y,d[nm],sample_weight=w),'Brier':brier_score_loss(y,d[nm],sample_weight=w)}
        for m,v in vals.items():
            expected=float(metrics.loc[metrics.cohort.eq(site)&metrics.model.eq(nm),m].iloc[0])
            checks.append({'cohort':site,'model':nm,'metric':m,'recomputed':v,'recorded':expected,'absolute_error':abs(v-expected)})
        grp=pd.qcut(d[nm],5,labels=False,duplicates='drop').to_numpy()
        for k in np.unique(grp):
            ix=grp==k
            bins.append({'cohort':site,'model':nm,'bin':int(k),'predicted':np.average(d[nm][ix],weights=w[ix]),'observed':np.average(y[ix],weights=w[ix]),'landmarks':int(ix.sum())})
        for t in np.arange(.1,.81,.05):
            positive=d[nm].to_numpy()>=t
            value=np.sum(w*y*positive)/sum(w)-np.sum(w*(1-y)*positive)/sum(w)*t/(1-t)
            nb.append({'cohort':site,'model':nm,'threshold':t,'net_benefit':value,'event_prevalence':np.average(y,weights=w)})
checks=pd.DataFrame(checks);assert checks.absolute_error.max()<1e-12
checks.to_csv(OUT/'verification/nested_metric_recomputation.csv',index=False)
bins=pd.DataFrame(bins);bins.to_csv(OUT/'results/nested_calibration_bins.csv',index=False)
nb=pd.DataFrame(nb);nb.to_csv(OUT/'results/exploratory_threshold_utility.csv',index=False)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','axes.titleweight':'bold'})
COLORS={'RF_current':'#52616B','OAF':'#087F8C','Global_AP':'#B26A38','Fixed_half':'#8F789E'}
fig=plt.figure(figsize=(12,4.1));gs=fig.add_gridspec(1,3,width_ratios=[1.13,1,1],wspace=.36)
ax=fig.add_subplot(gs[0]);labs=[]
for j,(site,suffix,label) in enumerate([('xuhui_oof','','A: raw'),('xuhui_oof','_cal','A: calibrated'),('fengxian','','B: raw'),('fengxian','_cal','B: calibrated')]):
    z=effects[(effects.cohort==site)&(effects.candidate=='OAF'+suffix)&(effects.reference=='RF_current'+suffix)&(effects.metric=='AUPRC')].iloc[0]
    ax.errorbar(z.difference,j,xerr=[[z.difference-z.ci_low],[z.ci_high-z.difference]],fmt='o',color='#087F8C' if suffix else '#52616B',capsize=3,ms=5)
    labs.append(label)
ax.set_yticks(range(4),labs);ax.invert_yaxis();ax.axvline(0,color='#999',lw=1,ls=':');ax.set_xlabel('OAF minus RF AUPRC');ax.set_title('(a) Paired increments',loc='left');ax.xaxis.set_major_locator(MaxNLocator(4));ax.grid(axis='x',alpha=.15)
for k,(site,title) in enumerate([('xuhui_oof','(b) Site A'),('fengxian','(c) Site B')],1):
    ax=fig.add_subplot(gs[k]);ax.plot([0,1],[0,1],':',color='#aaa',lw=1)
    for nm in ['RF_current','OAF']:
        for suffix,style in [('', '--'),('_cal','-')]:
            z=bins[(bins.cohort==site)&(bins.model==nm+suffix)]
            ax.plot(z.predicted,z.observed,style,marker='o',ms=4,color=COLORS[nm],label=('Current RF' if nm=='RF_current' else 'OAF')+(' calibrated' if suffix else ' raw'))
    ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_xlabel('Mean predicted probability');ax.set_ylabel('Observed intervention proportion');ax.set_title(title,loc='left');ax.grid(alpha=.15)
handles,labels=ax.get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.64,1.075),ncol=4,frameon=False,fontsize=9)
fig.subplots_adjust(top=.85,bottom=.17)
for ext in ['png','pdf','svg']:fig.savefig(FIG/f'Figure5.{ext}',dpi=300,bbox_inches='tight')
plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(10,4))
for ax,(site,title) in zip(axes,[('xuhui_oof','Site A: OOF'),('fengxian','Site B: exploratory')]):
    for nm in ['RF_current','Fixed_half','Global_AP','OAF']:
        z=nb[(nb.cohort==site)&(nb.model==nm+'_cal')]
        ax.plot(z.threshold,z.net_benefit,color=COLORS[nm],label=nm.replace('_',' '),lw=1.7)
    z=nb[nb.cohort==site];t=np.arange(.1,.81,.05);pi=z.event_prevalence.iloc[0]
    ax.plot(t,pi-(1-pi)*t/(1-t),':',color='#777',label='Classify all positive');ax.axhline(0,ls='--',color='#aaa',label='Classify none positive')
    ax.set_ylim(-.08,.4);ax.set_xlim(.1,.8);ax.set_title(title);ax.set_xlabel('Classification threshold');ax.set_ylabel('Net benefit (descriptive)');ax.grid(alpha=.15)
handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,1.055),ncol=3,frameon=False,fontsize=9);fig.subplots_adjust(wspace=.27,top=.81,bottom=.16)
for ext in ['png','pdf','svg']:fig.savefig(FIG/f'S18_threshold_utility.{ext}',dpi=300,bbox_inches='tight')
plt.close(fig)

